export type Choice = { label: string; next: string; trust?: number; courage?: number };
export type Scene = 'post' | 'pier' | 'school' | 'station';
export type StoryNode = {
  speaker: string;
  text: string;
  scene: Scene;
  chapter: number;
  perspective: string;
  character?: boolean;
  next?: string;
  choices?: Choice[];
};

export const chapters: Record<number, { no: string; title: string; perspective: string }> = {
  0: { no: '00', title: '世界边缘的信箱', perspective: '方舟' },
  1: { no: '01', title: '幸福日常的裂缝', perspective: '方舟' },
  2: { no: '02', title: '她看见的第一个八月', perspective: '夏澄' },
  3: { no: '03', title: '屋顶、语言与白栞', perspective: '白栞' },
  4: { no: '04', title: '同一天的第二次黄昏', perspective: '你' },
  5: { no: '05', title: '世界仍然如此', perspective: '方舟' },
};

export const story: Record<string, StoryNode> = {};

type Line = { speaker: string; text: string; scene?: Scene; character?: boolean };
function addSequence(prefix: string, chapter: number, defaultScene: Scene, perspective: string, lines: Line[]) {
  lines.forEach((line, index) => {
    const id = `${prefix}_${index}`;
    story[id] = {
      speaker: line.speaker,
      text: line.text,
      scene: line.scene || defaultScene,
      character: line.character,
      chapter,
      perspective,
      next: index < lines.length - 1 ? `${prefix}_${index + 1}` : undefined,
    };
  });
}

addSequence('c0', 0, 'post', '方舟', [
  { speaker: '旁白', text: '八月三十一日。群青町的最后一个暑假，被一阵咸涩的海风吹到了尽头。镇上的钟在六点整响了十三下，没有任何人抬头。' },
  { speaker: '我', text: '我叫方舟。至少学生证、作业本和夏澄都这样叫我。至于我自己为什么对这个名字感到陌生，那是从去年夏天起就没人愿意回答的问题。' },
  { speaker: '旁白', text: '旧邮局将在明早拆除。我本来只是来拍最后一张照片，却发现那只停用七年的蓝色信箱半开着，里面躺着一封没有邮票的信。' },
  { speaker: '我', text: '信封正面写着：“致八月三十一日的方舟”。背面则是我的笔迹——但落款日期是明天。' },
  { speaker: '信上的字', text: '「今晚九点，带夏澄去防波堤。不要让她知道你已经忘了白栞。也不要相信九点以后的我。」' },
  { speaker: '我', text: '白栞。这个名字像一枚掉进深井的硬币。我听见它触底，却想不起井里曾经装过什么。' },
  { speaker: '夏澄', text: '你果然在这里。明天就要离开群青町的人，不应该忙着收拾行李吗？', character: true },
  { speaker: '我', text: '夏澄的相机挂在胸前。取景框反着月光，我忽然产生一种荒唐的感觉：她不是来找我，而是来确认我还存在。' },
]);
story.c0_7.next = undefined;
story.c0_7.choices = [
  { label: '把来自“明天”的信交给夏澄', next: 'c0_truth', trust: 2, courage: 1 },
  { label: '隐去白栞的名字，只说防波堤的约定', next: 'c0_half', trust: 1 },
  { label: '假装信箱里什么都没有', next: 'c0_hide', courage: -1 },
];
story.c0_truth = { speaker: '夏澄', text: '她读到白栞的名字时，手指在信纸边缘停了很久。“原来你连她也忘了。这样的话，今晚也许真的会重新发生。”', scene: 'post', character: true, chapter: 0, perspective: '方舟', next: 'c1_0' };
story.c0_half = { speaker: '夏澄', text: '“只有防波堤？”她把问题重复了一遍，像是在确认我删去了哪一部分。随后她笑起来：“那就先陪我回学校取东西吧。”', scene: 'post', character: true, chapter: 0, perspective: '方舟', next: 'c1_0' };
story.c0_hide = { speaker: '我', text: '“只是来告别。”我把信塞进口袋。夏澄望着我鼓起的衣角，没有拆穿，只轻声说：“你还是和第一次一样。”', scene: 'post', chapter: 0, perspective: '方舟', next: 'c1_0' };

addSequence('c1', 1, 'school', '方舟', [
  { speaker: '旁白', text: '黄昏后的校舍没有开灯。自动门却为我们打开，广播里传出午休铃，墙上的电子钟显示八月三十日，十二点二十分。' },
  { speaker: '我', text: '“机器坏了？”我问。夏澄没有回答。她沿着走廊数门牌：二年三班、资料室、二年三班。相同的教室在尽头出现了两次。' },
  { speaker: '夏澄', text: '别看窗外。先告诉我，你记忆里的去年八月三十一日，天气是什么样的？', character: true },
  { speaker: '我', text: '晴天。毫无根据，但答案脱口而出。我记得天文台屋顶灼热的白光，记得有人在哭，也记得自己从三楼坠落——可病历上写的是“楼梯摔伤”。' },
  { speaker: '夏澄', text: '我的记忆里，那天下了整夜的雨。白栞说过：两个人使用不同的词描述同一片天空时，他们还活在同一个世界吗？', character: true },
  { speaker: '旁白', text: '天文社活动室里摆着三张椅子。桌上有一本值班日志，三种笔迹从去年七月持续到今天，其中一种属于我，另一种属于夏澄。第三种每一页都被整齐裁去。' },
  { speaker: '我', text: '抽屉里是一卷尚未冲洗的胶片，标签写着“幸福日常”。标签下方还有一行铅笔字：所谓日常，只是大家同意不去追问的部分。' },
  { speaker: '夏澄', text: '方舟，如果一张照片和你的记忆冲突，你会相信哪一个？', character: true },
  { speaker: '我', text: '她问得像一道早就公布过答案的考题。窗外传来海浪，可学校离海岸足有两公里。' },
  { speaker: '白栞的录音', text: '“测试，八月三十一日。方舟又迟到了。夏澄说世界不会因为一个人缺席就停止，但我认为，缺席本身会成为世界的形状。”' },
  { speaker: '我', text: '录音机里第三个人的声音清晰、平静。听到她念出我的名字时，我的右手开始发抖，像身体比记忆更早认出了她。' },
]);
story.c1_10.next = undefined;
story.c1_10.choices = [
  { label: '相信夏澄，把胶片交给她冲洗', next: 'c1_trust', trust: 2 },
  { label: '相信自己的记忆，收起胶片', next: 'c1_self', courage: 1 },
  { label: '先追问白栞现在在哪里', next: 'c1_shiori', trust: 1, courage: 1 },
];
story.c1_trust = { speaker: '夏澄', text: '“谢谢。”她没有接胶片，只握住了我递出的手。“比起照片，我更希望你先相信愿意和你一起看的人。”', scene: 'school', character: true, chapter: 1, perspective: '方舟', next: 'c2_0' };
story.c1_self = { speaker: '我', text: '我把胶片放进口袋。就在那一刻，活动室的第三张椅子消失了，仿佛它从未被任何人使用。夏澄闭上眼，像是在忍耐某种预料之中的疼痛。', scene: 'school', chapter: 1, perspective: '方舟', next: 'c2_0' };
story.c1_shiori = { speaker: '夏澄', text: '“她不在群青町。”夏澄说。“但只要我们还使用她留下的词，她就没有真正离开。你会觉得这是安慰，还是诅咒？”', scene: 'school', character: true, chapter: 1, perspective: '方舟', next: 'c2_0' };

addSequence('c2', 2, 'pier', '夏澄', [
  { speaker: '夏澄（心声）', text: '我第一次发现方舟忘了白栞，是去年的九月三日。他坐在病房里问我，为什么合照中间要空出一个人的位置。' },
  { speaker: '夏澄（心声）', text: '医生说创伤会选择性地切断记忆。可方舟忘掉的不只是事故：白栞用过的课桌、写过的文章、甚至所有人对她的称呼，都从他的世界里退了出去。' },
  { speaker: '白栞', text: '“如果事实只能通过语言进入一个人的世界，那么忘记某个人，是不是等于在自己的世界里杀死了她？”' },
  { speaker: '夏澄（心声）', text: '她在离开前问过我这个问题。那时我骂她把什么都说得像哲学题。后来才明白，她只是在请求我们不要把沉默当成善意。' },
  { speaker: '旁白', text: '画面中的夏澄站在一年前的防波堤。她举起相机，对准空无一人的海面。快门落下时，照片里却多出三个人的影子。' },
  { speaker: '夏澄（心声）', text: '所谓“来自明天的信”是我们三个人的游戏。每年八月三十一日写信，放进旧邮局的定时投递柜，让一年后的自己回答。' },
  { speaker: '夏澄（心声）', text: '最后一封信本该由白栞寄出。可事故以后，旧邮局停用，她也从群青町搬走。今天出现的那封信，不可能来自任何已知的投递格。' },
  { speaker: '白栞的录音', text: '“夏澄，你总想用照片证明世界存在。方舟总想用记忆证明自己存在。可如果你们互相凝视，也许根本不需要第三种证据。”' },
  { speaker: '夏澄（心声）', text: '我没有告诉方舟：事故那天不是他从天文台坠落，而是白栞推开了站在护栏外的他，自己摔伤了右腿。她没有死，也没有失踪。她只是不愿再被我们定义成受害者。' },
  { speaker: '夏澄（心声）', text: '我明天离开，不是因为父亲的工作。东京有一家康复中心，白栞在那里。我答应过带方舟去见她，却连续一年没有勇气完成。' },
  { speaker: '夏澄', text: '如果今晚他再次问起，我应该告诉他全部吗？还是让他留在没有白栞、也没有罪恶感的幸福日常里？', character: true },
]);
story.c2_10.next = undefined;
story.c2_10.choices = [
  { label: '真相即使残酷，也不属于任何人的私有物', next: 'c2_truth', trust: 1, courage: 2 },
  { label: '有些遗忘是心为了活下去搭起的屋顶', next: 'c2_mercy', trust: 2 },
];
story.c2_truth = { speaker: '夏澄（心声）', text: '那就告诉他。不是为了惩罚，也不是为了赎罪，而是因为只有知道自己站在哪里，一个人才有可能真正选择下一步。', scene: 'pier', character: true, chapter: 2, perspective: '夏澄', next: 'c3_0' };
story.c2_mercy = { speaker: '夏澄（心声）', text: '我会等到他自己伸手。屋顶不是谎言，它只是暂时替人挡雨。可雨停以后，我们终究应该看一眼天空。', scene: 'pier', character: true, chapter: 2, perspective: '夏澄', next: 'c3_0' };

addSequence('c3', 3, 'school', '白栞', [
  { speaker: '白栞', text: '如果你听到这一段，说明夏澄终于背叛了我。请不要责怪她。所谓朋友，大概就是愿意在必要时背叛彼此的谎言。' },
  { speaker: '旁白', text: '录音背景有规律的机械声，像列车，也像医院走廊的空调。白栞说话很慢，每次停顿都给听者留下拒绝继续的机会。' },
  { speaker: '白栞', text: '方舟，那天你不是想死。你只是想证明护栏之外的天空和护栏之内的天空属于同一个世界。这个想法很蠢，但我当时也没有更聪明。' },
  { speaker: '白栞', text: '我推开你，摔在下一层平台。你看见血，以为我坠楼。后来你忘了我，大家便配合你的遗忘，因为解释一个不存在的人，比承认我们都害怕更容易。' },
  { speaker: '白栞', text: '我搬走并不是牺牲。群青町每个人看我时，都只看见“救了方舟的白栞”。那不是我。我宁愿去一个没人知道我做过正确事情的地方，重新学习自私。' },
  { speaker: '白栞', text: '维特根斯坦说过，世界是事实的总体，而不是事物的总体。我以前很喜欢这句话。现在我怀疑：人活着需要的并不是事实总体，而是一小块可以和别人共同误解的地方。' },
  { speaker: '白栞', text: '所以我写下最后一封信，交给旧邮局的宫坂爷爷。投递日期不是明天，是事故后的第一年。他说机器坏了，我说没关系，坏掉的机器偶尔比正常的世界更守约。' },
  { speaker: '白栞', text: '信里那句“不要相信九点以后的我”不是警告你。是提醒我自己：录音里的白栞、照片里的白栞、你记忆恢复后的白栞，都不是此刻正在说话的我。' },
  { speaker: '白栞', text: '没有人能够被一句定义保存。就像天空并不因为被叫作群青色，就停止包含我们叫不出名字的颜色。' },
  { speaker: '白栞', text: '方舟，等你想起一切，请替我做一件事。不要请求我的原谅。把那张三个人的照片烧掉，然后重新拍一张——可以是两个人，也可以是一个人。' },
  { speaker: '旁白', text: '录音到这里中断。空白持续了四十七秒。最后，白栞在很远的地方补了一句：“当然，如果你们还愿意，也可以来东京找我。”' },
]);
story.c3_10.next = 'c4_0';

addSequence('c4', 4, 'post', '你', [
  { speaker: '旁白', text: '九点整，镇上的钟第二次响了十三下。你回到旧邮局，发现自己又站在傍晚六点的信箱前。手里没有信，口袋里却多了一张尚未冲洗的胶片。' },
  { speaker: '我', text: '我知道接下来会发生什么：夏澄从坡道尽头走来，问我为什么不收拾行李；学校的门会打开；广播会播放错误的铃声；白栞的声音会在暗处叫出我的名字。' },
  { speaker: '旁白', text: '但这一次，夏澄没有出现。街上的行人也消失了。所有招牌都失去文字，只剩颜色和形状，像世界尚未学会如何称呼自己。' },
  { speaker: '信箱里的声音', text: '当一个故事被重新讲述，究竟是同一天发生了第二次，还是另一个你第一次抵达这里？' },
  { speaker: '我', text: '我摸到信箱内壁刻着三组名字：方舟、夏澄、白栞。下面还有第四组新鲜划痕——“你”。' },
  { speaker: '旁白', text: '直到此刻，你才意识到，方舟从来没有选择过任何选项。把信交出去、隐藏名字、相信照片或记忆的人，一直是屏幕外的你。' },
  { speaker: '我', text: '如果记忆构成了我，选择构成了你，那么此刻共同读到这句话的“我们”，是否比任何一张照片都更接近事实？' },
  { speaker: '夏澄', text: '别怕。故事不是陷阱。它只是在借你的眼睛，让我们得到一次没有发生过的坦白。', character: true },
  { speaker: '我', text: '夏澄站在没有文字的世界里。她的轮廓被月光照亮，相机镜头中不是我的倒影，而是一封等待填写收件人的空白信。' },
  { speaker: '夏澄', text: '现在你知道了三个版本：方舟忘记的世界、我隐瞒的世界、白栞拒绝被定义的世界。你愿意让哪一个成为“真的”？', character: true },
]);
story.c4_9.next = undefined;
story.c4_9.choices = [
  { label: '三个版本都不完整，所以三个都是真的', next: 'c4_many', trust: 2, courage: 2 },
  { label: '相信此刻愿意互相坦白的人', next: 'c4_now', trust: 3, courage: 1 },
  { label: '事实只有一个，必须找出唯一正确的版本', next: 'c4_fact', courage: 2 },
];
story.c4_many = { speaker: '信箱里的声音', text: '世界没有因此裂成三块。相反，那些互相矛盾的天空在海平线上重叠，显出一种从未被命名过的蓝。', scene: 'post', chapter: 4, perspective: '你', next: 'c5_0' };
story.c4_now = { speaker: '夏澄', text: '“那就从现在开始。”她按下快门。没有闪光，也没有照片吐出，但街道的文字一个接一个回来了。', scene: 'post', character: true, chapter: 4, perspective: '你', next: 'c5_0' };
story.c4_fact = { speaker: '旁白', text: '你坚持寻找唯一答案。信箱吐出医院记录、车票、照片和证词，每一份证据都真实，每两份证据又彼此冲突。事实越来越多，世界却越来越窄。', scene: 'post', chapter: 4, perspective: '你', next: 'c5_0' };

addSequence('c5', 5, 'station', '方舟', [
  { speaker: '旁白', text: '九月一日，清晨六点。群青町站的广播准确报时，没有重复的教室，没有失去文字的招牌。世界恢复正常——或者只是我们重新同意把它称作正常。' },
  { speaker: '我', text: '全部记忆并没有回来。我依然想不起白栞喜欢哪种汽水，想不起她写字时先落哪一笔。但我记得她不是一个需要被保存的概念，而是正在东京过自己生活的人。' },
  { speaker: '夏澄', text: '车票买好了。东京，两张。你可以现在跟我走，也可以等准备好以后再来。无论怎么选，我都不会替你把它叫作勇敢或逃避。', character: true },
  { speaker: '我', text: '她把旧照片递给我。照片中央果然站着白栞，右手举着写有“世界不会在这里结束”的纸牌。过去没有改变，改变的是我终于允许它复杂。' },
  { speaker: '夏澄', text: '那封来自明天的信，还剩最后一页。收件人不是你，也不是我。', character: true },
  { speaker: '旁白', text: '空白信纸最上方写着：“致读到这里的人”。列车即将进站，纸张在风里震动，等待一个不属于故事内部的回答。' },
  { speaker: '信上的字', text: '如果幸福建立在某种遗忘上，你愿意掀开它吗？如果真相不能带来幸福，你仍然愿意让另一个人拥有它吗？' },
  { speaker: '我', text: '我没有替你回答。因为世界也许是事实的总体，也许是语言的边界，也许只是清晨站台上，两个不完整的人愿意共同承担的下一秒。' },
  { speaker: '夏澄', text: '列车来了。方舟——还有屏幕外的你——要一起去看看白栞现在的天空吗？', character: true },
]);
story.c5_8.next = undefined;
story.c5_8.choices = [
  { label: '登上列车，去见真实而陌生的白栞', next: 'resolve', trust: 2, courage: 2 },
  { label: '留在群青町，先写完属于自己的信', next: 'resolve', trust: 1, courage: 1 },
  { label: '把空白信放回箱中，不替未来作答', next: 'resolve' },
];

export const storyLength = Object.keys(story).length;
