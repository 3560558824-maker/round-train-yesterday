import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '昨日圆车｜原创策略塔防游戏',
  description: '昨日失窃后，末代调度员与八名行者沿环城线逆行，守护被回收兽吞噬的城市记忆。',
  openGraph: {
    title: '昨日圆车｜原创策略塔防游戏',
    description: '昨日失窃后，末代调度员与八名行者沿环城线逆行，守护被回收兽吞噬的城市记忆。',
    type: 'website',
    images: [{ url: '/og.png', width: 1200, height: 630, alt: '昨日圆车' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: '昨日圆车｜原创策略塔防游戏',
    description: '昨日失窃后，末代调度员与八名行者沿环城线逆行，守护被回收兽吞噬的城市记忆。',
    images: ['/og.png'],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
