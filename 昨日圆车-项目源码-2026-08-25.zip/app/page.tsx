'use client';

import { useEffect, useReducer, useRef, useState } from 'react';

type OperatorId = 'lith' | 'kite' | 'bell' | 'mend' | 'flare' | 'anchor' | 'loom' | 'echo' | 'clockline';
type Direction = 'up' | 'right' | 'down' | 'left';
type StageId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15;
type LobbySection = 'home' | 'operations' | 'training' | 'archive' | 'announcements';
type GameMode = 'title' | 'lobby' | 'formation' | 'briefing' | 'running' | 'paused' | 'won' | 'lost';
type EnemyKind = 'rust' | 'runner' | 'shell' | 'wisp' | 'leech' | 'clock';
type OperatorLevels = Record<OperatorId, number>;
type PlayerProgress = { fragments: number; cleared: number; levels: OperatorLevels; squad: OperatorId[] };

type Unit = {
  id: number; opId: OperatorId; cell: number; hp: number; maxHp: number;
  skill: number; skillTimer: number; attackCooldown: number; shield: number; rewindHp: number; rewindTimer: number;
  attackFx: number; skillFx: number; hurtFx: number; healFx: number; direction: Direction; level: number;
  attackTargetRow: number | null; attackTargetCol: number | null;
};
type Enemy = {
  id: number; kind: EnemyKind; route: number; pos: number; hp: number; maxHp: number;
  speed: number; attack: number; physicalResistance: number; arcaneResistance: number; attackInterval: number;
  attackCooldown: number; attackFx: number; slowTimer: number; stunTimer: number; markTimer: number; hitFx: number; attacking: boolean;
};
type GameState = {
  mode: GameMode; cost: number; lives: number; killed: number; spawned: number;
  elapsed: number; nextSpawn: number; selected: OperatorId | null; selectedUnit: number | null;
  speed: 1 | 2; units: Unit[]; enemies: Enemy[]; redeploy: Record<OperatorId, number>; message: string;
  stageId: StageId; levels: OperatorLevels; runId: number;
  squad: OperatorId[];
};

const COLS = 8;
const CHAPTER_ROUTES: Record<number, number[][]> = {
  1: [[16, 17, 18, 19, 27, 35, 36, 37, 38, 39]],
  2: [
    [8, 16, 24, 25, 26, 27, 28, 20, 12, 13, 14, 15],
    [40, 32, 24, 25, 26, 27, 28, 36, 37, 38, 39],
    [24, 25, 26, 18, 19, 20, 12, 13, 14, 15],
  ],
  3: [
    [32, 33, 25, 17, 18, 19, 27, 35, 36, 37, 38, 39],
    [0, 1, 9, 17, 18, 19, 11, 3, 4, 5, 6, 7],
    [40, 41, 33, 25, 17, 18, 19, 11, 3, 4, 5, 6, 7],
  ],
  4: [
    [24, 16, 17, 18, 26, 34, 35, 36, 28, 20, 21, 22, 23],
    [0, 1, 9, 17, 18, 26, 34, 35, 36, 37, 38, 39],
    [40, 41, 33, 25, 26, 34, 35, 36, 28, 20, 21, 22, 23],
  ],
  5: [
    [40, 41, 33, 25, 26, 18, 19, 20, 28, 29, 30, 22, 23],
    [0, 1, 9, 17, 18, 19, 20, 12, 13, 14, 15],
    [24, 25, 26, 18, 19, 27, 35, 36, 37, 38, 39],
  ],
};
const CHAPTER_TWO_MERGE_ROUTE = [40, 32, 24, 25, 26, 27, 28, 20, 12, 13, 14, 15];
const stageRoutes = (stageId: StageId) => {
  const routes = CHAPTER_ROUTES[Math.ceil(stageId / 3)];
  if (stageId <= 3) return routes.slice(0, 1);
  if (stageId === 4) return [routes[0], CHAPTER_TWO_MERGE_ROUTE];
  if (stageId === 5) return routes.slice(0, 2);
  if (stageId === 6) return routes;
  if (stageId <= 8) return routes.slice(0, 2);
  return routes;
};
const stagePath = (stageId: StageId, route = 0) => {
  const routes = stageRoutes(stageId);
  return routes[Math.min(route, routes.length - 1)];
};
const stageRouteProfile = (stageId: StageId) => {
  const routes = stageRoutes(stageId);
  return { routes, spawns: new Set(routes.map((route) => route[0])).size, goals: new Set(routes.map((route) => route[route.length - 1])).size };
};
const operatorIds: OperatorId[] = ['lith', 'kite', 'bell', 'mend', 'flare', 'anchor', 'loom', 'echo', 'clockline'];
const stageIds: StageId[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
const MAX_LEVEL = 10;
const defaultLevels: OperatorLevels = { lith: 1, kite: 1, bell: 1, mend: 1, flare: 1, anchor: 1, loom: 1, echo: 1, clockline: 1 };

const chapters = [
  { id: 1, no: 'CHAPTER 01', title: '没有昨天的早晨', subtitle: '环城旧线仍在逆行，所有人却忘了为何出发。', color: '#d8ef3e' },
  { id: 2, no: 'CHAPTER 02', title: '拼成一个孩子', subtitle: '小满从回收兽腹中，拾回不属于任何一人的童年。', color: '#54dce3' },
  { id: 3, no: 'CHAPTER 03', title: '背叛者的时刻表', subtitle: '迟鸦决定让圆车停下，即使必须亲手切断昨日。', color: '#b77aff' },
  { id: 4, no: 'CHAPTER 04', title: '抵达明日的人', subtitle: '逆行、顺行，或拆解圆车——终点要求最后一次调度。', color: '#ff8448' },
  { id: 5, no: 'CHAPTER 05', title: '第一场真正的雨', subtitle: '圆车停下以后，城市必须学会在没有时刻表的日子里继续生活。', color: '#65e8a7' },
] as const;

const announcements = [
  {
    version: 'MAP TUNING', date: '2026.08.25', tag: 'NEW', title: '第二章开始进入复线调度',
    summary: '路线复杂度的成长点提前到第二章，并在 YR-4 至 YR-6 内逐关增加入口、分岔和守护点。',
    changes: ['YR-4 使用双入口汇流，让玩家第一次处理两侧同时出怪。', 'YR-5 将汇流改为分岔，敌人会分别前往两个守护点。', 'YR-6 启用三处入口与三条路线，要求编队兼顾中心交汇区和两端防线。', '第二章关前敌情会准确显示各关入口、路线和守护点数量。'],
  },
  {
    version: 'ROUTE UPDATE', date: '2026.08.25', tag: 'NEW', title: '多入口、分岔与多守护点地图',
    summary: '地图复杂度现在会随主线推进逐步提高：教学关保持单线，后续行动依次加入双入口、汇流、分岔和多个守护点。',
    changes: ['第一章保持单入口单终点，便于熟悉部署与朝向；第二章开始让敌人从两处裂口交替出现。', '第二章后段已加入真正的轨道分岔、三路进攻与两个守护点，复杂度随关卡连续成长。', '第四、第五章采用三入口、多分岔与最多三个守护点；敌人会按各自路线独立寻路。', '战场会标出分岔格和全部出入口，关前敌情页同步显示本关路线、入口和守护点数量。'],
  },
  {
    version: 'ENEMY UPDATE', date: '2026.08.25', tag: 'NEW', title: '前四章回收兽机制补充',
    summary: '早期敌人不再只依靠移动、生命和攻击区分；新增可观察、可针对，同时不会显著抬高通关门槛的轻量机制。',
    changes: ['锈忆兽被击退时返还 1 点部署费用，让前期阵线拥有更稳定的调整空间。', '急行残影从第二关起入场短暂冲刺；第五章冲刺幅度更高，战场会直接显示“冲刺”。', '沉积甲壳在未被阻挡时展开护壳；地面行者成功阻挡或令其停摆即可解除减伤。', '空忆灯蛾攻击时显示“空袭”，食忆藤兽攻击回血时显示“汲取”，原有机制更容易辨认。'],
  },
  {
    version: 'DIALOGUE UPDATE', date: '2026.08.25', tag: 'NEW', title: '十五关关前角色对话演出',
    summary: '每次行动在正式开战前进入逐句剧情对话。旁白、行者与零号会先交代现场，玩家阅读完剧情并确认敌情后，敌人才会开始出现。',
    changes: ['十五关使用各自的行动记录、现场记忆、角色台词与零号广播组成可推进对话。', '岑昼、小满、迟鸦等出场角色会显示姓名、身份与独立立绘；零号拥有专属广播演出。', '支持上一句、下一句、点击画面继续与跳过对话；结束后进入单独的敌情确认页。', '只有在敌情确认页接受调度后才开始计时、刷怪和战斗。'],
  },
  {
    version: 'CHAPTER UPDATE', date: '2026.08.25', tag: 'NEW', title: '第五章与渐进难度行动开放',
    summary: '主线新增三段可游玩行动。压力通过路线、敌人组合和出场节奏逐关递进，后期敌人数值成长同步放缓，避免只靠堆高生命与攻击制造难度。',
    changes: ['新增第五章“第一场真正的雨”与 YR-13 至 YR-15，主线扩展为五章十五关。', 'YR-13 先复习高速与空中目标；YR-14 加入高物抗、高法抗敌人的混合应对；YR-15 才让首领与完整敌群共同登场。', '新增强化冲刺、强化护壳与首领残响加速机制；关前情报和战场状态会直接提示应对方式。', '新关卡采用更长的折返路线、较宽松的波次间隔，并限制终局数值增幅，让培养适中的六人编队也能通关。', '新增第五章关前剧情、战中广播、行动余波和独立幕间，并同步写入剧情档案。'],
  },
  {
    version: 'MAP UPDATE', date: '2026.08.25', tag: 'NEW', title: '战场环境与地形识别优化',
    summary: '行动地图加入更具实感的环城设施，并重新设计轨道地面与架空高台，让部署区域无需试错即可辨认。',
    changes: ['地面轨道加入连续钢轨、枕木、接缝和磨损纹理，明确对应近战行者部署区域。', '远程高台改为抬升式金属平台，加入侧壁厚度、角部固定栓与蓝色平台编号。', '战场增加信号灯、通风机、检修管线、隔离栏、蒸汽与扫描光等环境设施。', '四个章节使用不同环境光与雾色；部署高亮、攻击范围及原有战斗判定保持不变。'],
  },
  {
    version: 'OPERATOR UPDATE', date: '2026.08.25', tag: 'NEW', title: '九名行者机制型技能重制',
    summary: '所有手动技能停止使用单纯的攻击力叠加，改为回溯、标记、击退、护盾、费用回收、眩晕、减速场、再部署支援与时间冻结。',
    changes: ['岑昼回溯生命并反击阻挡目标；雾筝标记敌人并穿透抗性；迟鸦令范围内敌人倒退并停摆。', '祈修为范围内行者缝合护盾；小满回收费用并投掷记忆瓶；砾灯震晕周围敌人并获得屏障。', '萤返展开持续减速的信号场并连锁攻击；回声复写生命比例并缩短全队再部署时间。', '钟离线冻结范围内敌人，技能期间攻击覆盖整个攻击范围；战场新增护盾、标记与停摆提示。'],
  },
  {
    version: 'NARRATIVE UPDATE', date: '2026.08.25', tag: 'NEW', title: '记忆切片与章节幕间扩充',
    summary: '十二段行动加入更多人物对话、战中广播与战后余波，四章剧情档案新增独立幕间记录。',
    changes: ['每关行动前新增一段现场记录和两句角色对话，补充队伍关系与任务动机。', '十二关各增加一条中后段战斗广播，让剧情随敌潮推进。', '通关结算新增“行动余波”与人物短对话，展示夺回记忆后的代价。', '剧情档案新增四篇章节幕间，并随相应章节进度逐步解锁。'],
  },
  {
    version: 'TACTICS UPDATE', date: '2026.08.25', tag: 'NEW', title: '六人编队、双抗与群法师',
    summary: '战前决策正式扩展：根据回收兽抗性挑选出战行者，以物理、术法与范围伤害组织阵线。',
    changes: ['新增战前编队界面；九名行者中最多选择六人出战，编队会自动保存。', '回收兽新增物理抗性与术法抗性，战前情报及行动内档案均可查看。', '新增群法师“钟离线”，术法攻击会在目标周围造成范围伤害。', '行动终端加入配队提示，帮助调度员针对高抗性目标选择伤害类型。'],
  },
  {
    version: 'STORY UPDATE', date: '2026.08.25', tag: 'CONTENT', title: '四章十二关完整调度线',
    summary: '调度大厅、战斗副本、行者养成与剧情档案已形成完整流程。',
    changes: ['主线扩展为四个章节、十二段行动，并为各章配置独立轨道路线与敌群。', '加入关前剧情、战斗广播和关后记忆结算，补完零号、岑昼、小满与迟鸦的故事。', '新增昨日残片与永久升级系统，行者可提升生命、攻击、治疗及攻速。', '大厅支持查看主线进度、培养资源与已经恢复的剧情档案。'],
  },
  {
    version: 'COMBAT UPDATE', date: '2026.08.24', tag: 'COMBAT', title: '战场角色、怪物与打击表现升级',
    summary: '行者与回收兽拥有独立战场造型、攻击动作、受击反馈和技能表现。',
    changes: ['八名初始行者加入角色立绘、分帧攻击动作和职业对应特效。', '远程投射物会追踪锁定目标，伤害与命中特效在抵达敌人时结算。', '回收兽保留完整原始轮廓，并增加移动、攻击、受击和死亡动作。', '接入审核通过的战斗音效；技力充满时会在行者上方高亮提示。'],
  },
  {
    version: 'DEPLOY UPDATE', date: '2026.08.24', tag: 'SYSTEM', title: '定点部署、滑动定向与再部署',
    summary: '部署流程调整为两步确认，避免拖动时碰到第一个格子就错误落地。',
    changes: ['从预备栏拖到目标格并松手后，进入方向选择而非立即部署。', '在角色周围滑向上下左右并松手确认朝向，也可随时取消本次部署。', '行者战败后进入再部署倒计时，倒计时结束后才可重新上场。', '点击场上行者显示详细信息，点击空白区域收起面板；暂停菜单可返回大厅。'],
  },
] as const;

const stages: Record<StageId, {
  chapterId: number; chapter: string; operation: string; title: string; location: string; story: string; quote: string; broadcast: string;
  dialogue: { speaker: string; text: string }[]; battleLines: [string, string];
  objective: string; reward: number; total: number; cuts: [number, number]; spawnGap: number;
  sequence: EnemyKind[]; intel: EnemyKind[]; victory: string; boss?: EnemyKind;
}> = {
  1: { chapterId: 1, chapter: '第一章', operation: 'YR-1', title: '没有昨天的早晨', location: '环城旧线', story: '你在空无一人的调度室醒来。钟表停在 07:42，全城的人记得姓名、工作与回家的路，却没有一个人记得昨天。桌面只有一张属于你的纸条，墨迹像刚刚写下。', quote: '“不要让列车顺时针行驶。”', broadcast: '环城旧线仍保存着一段街区记忆。接受调度后，回收兽将立即出现。', dialogue: [{ speaker: '岑昼', text: '名字册上写着我今天仍是队长。请下令吧，陌生的调度员。' }, { speaker: '小满', text: '裂口里有甜味，是别人丢掉的早餐和道别。' }, { speaker: '零号', text: '列车必须逆行。至少今天，先相信广播里的我。' }], battleLines: ['旧城居民正在同时忘记门牌号，守住这条轨道。', '你又失败了一次……不，我不该这么早说这句话。'], objective: '保护环城旧线，阻止回收兽吞噬第一街区记忆。', reward: 100, total: 16, cuts: [5, 11], spawnGap: 2.2, sequence: ['rust', 'rust', 'runner', 'rust', 'runner'], intel: ['rust', 'runner'], victory: '夺回的并非城市公共记忆，而是你第一次登上圆车、对零号说“明天见”的那一天。作为交换，你已经想不起母亲说话时的声音。' },
  2: { chapterId: 1, chapter: '第一章', operation: 'YR-2', title: '名字册上的空行', location: '守门人站', story: '岑昼每天醒来都会忘记队友。他的名字册却多出一行被反复擦去的记录：第九名行者，末代调度员。那行字的笔迹与你桌上的纸条完全相同。', quote: '“如果我明天不认识你，请把名字册翻到最后一页。”', broadcast: '守门人站的记忆门正在关闭。岑昼会挡住兽群，你要替他记住谁仍站在这里。', dialogue: [{ speaker: '岑昼', text: '我记得战术，不记得并肩作战的人。这算不算一种背叛？' }, { speaker: '砾灯', text: '轨道记得脚步。你忘了谁，我就再敲一遍名字。' }, { speaker: '迟鸦', text: '记忆并不可靠，调度员。别把一本册子当成灵魂。' }], battleLines: ['第二道记忆门开启，沉积甲壳正在挤入站台。', '岑昼的名字册少了一页。有人在循环开始前动过它。'], objective: '守住记忆门，确认岑昼名字册中被删除的记录。', reward: 120, total: 18, cuts: [6, 12], spawnGap: 2.08, sequence: ['rust', 'runner', 'rust', 'shell', 'runner', 'rust'], intel: ['rust', 'runner', 'shell'], victory: '最后一页只写着一句话：“不要让岑昼想起零号。”你记得自己写下了它，却想不起为什么手在发抖。' },
  3: { chapterId: 1, chapter: '第一章', operation: 'YR-3', title: '被抹去的站台', location: '第七码头', story: '官方线路图上没有第七码头，圆车却每一圈都在那里减速。站台长椅摆着九张旧车票，其中一张印着你的名字，日期来自“昨日失窃”发生前的最后一天。', quote: '“若没有人记得，站台还算存在吗？”', broadcast: '空忆灯蛾将越过阻挡。找回站台记录，也找回第九张车票的乘客。', dialogue: [{ speaker: '小满', text: '这里藏着很多孩子等人来接的下午。' }, { speaker: '回声', text: '录音里有人说：列车已经试运行了七百三十一次。' }, { speaker: '零号', text: '不要读取第九张票。那不是给现在的你留下的。' }], battleLines: ['空中记忆潮接近，优先清理灯蛾。', '录音校验完成：本次循环编号，七百三十二。'], objective: '夺回第七码头档案，截断第一次大规模记忆潮。', reward: 150, total: 22, cuts: [7, 15], spawnGap: 1.95, sequence: ['rust', 'wisp', 'runner', 'rust', 'shell', 'wisp', 'runner'], intel: ['wisp', 'runner', 'shell'], victory: '第九张车票的背面留着零号的字：“如果你读到这里，说明我又没能让你忘记我。”第一章档案恢复，循环的存在被正式确认。', boss: 'shell' },
  4: { chapterId: 2, chapter: '第二章', operation: 'YR-4', title: '夏天遗失招领处', location: '潮汐仓库', story: '小满说仓库里下着只有她能看见的雨。每一滴雨都是一名市民遗失的童年：没送出的糖、被撕掉的奖状、没有等到的家长。回收兽正在把它们压成没有主人的燃料。', quote: '“我能把昨天还给他们，可我该把自己还给谁？”', broadcast: '潮汐仓库出现食忆藤兽。它会从伤口中抽取记忆并自我恢复。', dialogue: [{ speaker: '小满', text: '这些记忆都认识我，可没有一段记忆叫我的名字。' }, { speaker: '祈修', text: '被拼起来的人也会疼。疼痛足够证明你不是物品。' }, { speaker: '零号', text: '调度员，别让她独自打开最深处的箱子。' }], battleLines: ['藤兽开始汲取行者记忆，集中火力切断它。', '仓库深层检测到数千个相同生日：那是小满醒来的日期。'], objective: '保护拾忆作业，阻止藤兽消化童年记忆。', reward: 165, total: 22, cuts: [7, 15], spawnGap: 1.92, sequence: ['leech', 'rust', 'runner', 'leech', 'wisp', 'rust'], intel: ['leech', 'wisp', 'rust'], victory: '箱子里没有小满的出生记录，只有一份“市民童年记忆重组计划”。签署人是前任调度员零号。' },
  5: { chapterId: 2, chapter: '第二章', operation: 'YR-5', title: '无人毕业的教室', location: '旧城第六校', story: '午夜清空之后，学生每天都回到同一堂毕业课。他们记得公式，却忘了彼此的绰号。雾筝在操场上放起一只旧风筝，线的另一端通向回收兽巢穴。', quote: '“毕业不是离开学校，是允许昨天留在身后。”', broadcast: '风筝线已标出兽群路线。高速残影将从侧线连续突入。', dialogue: [{ speaker: '雾筝', text: '地图不是为了回去，而是为了证明我们从哪里走来。' }, { speaker: '萤返', text: '信号灯连续亮了三次——有人从未来向我们发求救码。' }, { speaker: '迟鸦', text: '未来为什么要求我们保存一间无人记得的教室？' }], battleLines: ['高速目标进入测绘线，雾筝已完成标记。', '未来信号译码：不要让小满接近圆车核心。'], objective: '清除校园侧线，取回被吞噬的毕业日。', reward: 180, total: 24, cuts: [8, 16], spawnGap: 1.82, sequence: ['runner', 'runner', 'wisp', 'rust', 'runner', 'leech'], intel: ['runner', 'wisp', 'leech'], victory: '毕业照上，小满站在每一个孩子原本的位置。照片背面写着：“当所有童年被拼成一个人，她会替城市承担第一次遗忘。”' },
  6: { chapterId: 2, chapter: '第二章', operation: 'YR-6', title: '拼成一个孩子', location: '童年回收井', story: '回收井底堆积着全城最早被夺走的记忆。小满听见成千上万名孩子同时叫她回家。“明日”则承诺，只要她走进核心，所有童年都会回到原主。', quote: '“如果他们都想起自己，我是不是就会消失？”', broadcast: '小满不是容器。守住回收井，让她自己决定要留下什么。', dialogue: [{ speaker: '岑昼', text: '名字册今天第一次自己写下了小满。' }, { speaker: '小满', text: '我想把记忆还回去，也想留下一小段只属于我的昨天。' }, { speaker: '零号', text: '那就活着回来。选择本身，就是你的第一段人生。' }], battleLines: ['回收井核心开启，沉积甲壳正在保护汲取装置。', '小满已取回一段私人记忆：她第一次叫出自己的名字。'], objective: '守住回收井，阻止“明日”回收小满的自我意识。', reward: 220, total: 27, cuts: [9, 18], spawnGap: 1.76, sequence: ['leech', 'shell', 'wisp', 'runner', 'leech', 'shell'], intel: ['leech', 'shell', 'wisp'], victory: '小满归还了大部分童年，却留下一只不属于任何原主的纸船。她说这是自己今天刚学会折的。第二章结束：拼合的记忆第一次创造了新的昨日。', boss: 'shell' },
  7: { chapterId: 3, chapter: '第三章', operation: 'YR-7', title: '历务局封锁令', location: '中央档案桥', story: '历务局宣布圆车非法，封锁所有通往终点的轨道。迟鸦交出研究员证件为行者争取通行，却没有解释为何封锁令上带着他的私人印章。', quote: '“保存历史的人，最擅长决定哪些历史不该存在。”', broadcast: '档案桥已被记忆沉积物覆盖。迟鸦要求亲自接入控制台。', dialogue: [{ speaker: '迟鸦', text: '我研究圆车十二年，只得到一个结论：它靠我们的痛苦维持循环。' }, { speaker: '砾灯', text: '所以你打算先让所有轨道一起断掉？' }, { speaker: '零号', text: '允许他接入。某些背叛必须发生，循环才会继续向前。' }], battleLines: ['档案桥承重下降，甲壳兽正在压垮中段轨道。', '检测到未授权指令：圆车制动权限已被复制。'], objective: '突破历务局封锁，护送迟鸦抵达中央控制台。', reward: 230, total: 26, cuts: [8, 17], spawnGap: 1.78, sequence: ['shell', 'rust', 'runner', 'shell', 'leech', 'wisp'], intel: ['shell', 'leech', 'wisp'], victory: '控制台恢复后，圆车短暂停止逆行。全城在一秒内想起了同一个画面：零号站在燃烧的首班车前，按下循环按钮。' },
  8: { chapterId: 3, chapter: '第三章', operation: 'YR-8', title: '逆行者离队', location: '制动塔', story: '迟鸦承认复制密码的人是他。他要摧毁制动塔，让圆车永远无法继续逆行。不是因为效忠“明日”，而是因为他记得循环开始前的城市有多痛苦。', quote: '“遗忘或许不是灾难，而是人类最后的自救。”', broadcast: '迟鸦已经离队。回收兽与历务局无人机同时逼近制动塔。', dialogue: [{ speaker: '迟鸦', text: '你每救回一个昨天，就失去一段更早的人生。你还剩多少自己？' }, { speaker: '岑昼', text: '我每天都失去所有人，但每天仍选择重新认识他们。' }, { speaker: '零号', text: '不要追他。先保护制动塔——这一次，他必须亲眼看到结果。' }], battleLines: ['制动塔外壁破裂，空中单位正在穿越阻挡。', '迟鸦没有引爆炸药。他在等待调度员作出回答。'], objective: '守住制动塔，在迟鸦启动永久刹车前控制局势。', reward: 245, total: 28, cuts: [9, 19], spawnGap: 1.7, sequence: ['runner', 'wisp', 'leech', 'shell', 'runner', 'wisp'], intel: ['runner', 'wisp', 'leech'], victory: '你告诉迟鸦：守护昨日不是服从昨日。迟鸦交回半枚制动钥匙，另一半扔进了未来裂口——他说，想要答案就去终点取。' },
  9: { chapterId: 3, chapter: '第三章', operation: 'YR-9', title: '前任调度员', location: '零号车厢', story: '圆车最深处终于开启。广播中的少女并非录音：零号的身体被固定在循环核心，每一次午夜清空都由她承受第一轮遗忘。她曾是你的搭档，也是第一个劝你拆掉圆车的人。', quote: '“请不要寻找我。找到我的那一天，就是圆车停下的那一天。”', broadcast: '你已经找到我。现在，替我守住这节车厢，直到我说完最后一段真相。', dialogue: [{ speaker: '零号', text: '第一次循环，是你要求我启动的。因为那天全城没有一个人准备好失去昨天。' }, { speaker: '迟鸦', text: '而我们把“没有准备好”重复了七百多次。' }, { speaker: '小满', text: '那这一次，可以让每个人自己准备吗？' }], battleLines: ['核心压力超过安全值，逆时钟兽正在成形。', '零号证言上传完成：循环从来不是唯一方案。'], objective: '保护零号车厢，听完循环建立者留下的完整证言。', reward: 280, total: 30, cuts: [10, 20], spawnGap: 1.64, sequence: ['wisp', 'leech', 'shell', 'runner', 'rust', 'wisp'], intel: ['clock', 'wisp', 'shell'], victory: '零号承认，“昨日失窃”并非意外，而是未来恐惧在圆车试验中获得意识的结果。那道意志给自己取名“明日”。', boss: 'clock' },
  10: { chapterId: 4, chapter: '第四章', operation: 'YR-10', title: '两个零号的广播', location: '午夜分岔口', story: '午夜前十分钟，广播里同时出现两个零号。过去的零号要求继续逆行，未来的零号要求立即顺行。她们都拥有正确的记忆，也都声称另一方是“明日”伪造的。', quote: '“真相不是哪一个声音更像我，而是哪一个选择允许你继续成为你。”', broadcast: '分岔口即将切换。保持轨道稳定，不要让任何声音替你下令。', dialogue: [{ speaker: '回声', text: '两段声纹完全一致，连呼吸停顿都相同。' }, { speaker: '祈修', text: '记忆可以复制，但承担选择的人只有一个。' }, { speaker: '末代调度员', text: '这一次，广播只提供信息。方向由活着的人决定。' }], battleLines: ['分岔器遭受冲击，守住切换窗口。', '双重广播正在合并：零号把最后权限交给了你。'], objective: '守住午夜分岔口，夺回圆车最终方向控制权。', reward: 290, total: 30, cuts: [10, 20], spawnGap: 1.62, sequence: ['runner', 'wisp', 'rust', 'leech', 'shell', 'runner'], intel: ['runner', 'wisp', 'shell'], victory: '两个声音都是真的：一个是启动循环时的零号，一个是经历七百三十二次失败后的零号。她们第一次共同说出：“不要再替所有人决定。”' },
  11: { chapterId: 4, chapter: '第四章', operation: 'YR-11', title: '顺时针的一公里', location: '明日试验线', story: '圆车第一次顺时针移动了一公里。城市没有立刻毁灭，旧记忆却开始像雪一样从车窗外剥落。每个人都能选择抓住一段，也必须亲手放开另一段。', quote: '“放下不是背叛，忘记也不等于从未发生。”', broadcast: '试验线只开放九十秒。“明日”会把所有恐惧投进这段轨道。', dialogue: [{ speaker: '萤返', text: '前方信号第一次不是红色。原来明日也有灯。' }, { speaker: '岑昼', text: '我选择记住名字册，不强迫名字册替我记住所有人。' }, { speaker: '迟鸦', text: '如果顺行可行，我会为过去的极端付出代价，但不会收回质疑。' }], battleLines: ['顺行数据稳定，兽群强度正在快速上升。', '一公里完成。城市保留了选择，而不是被迫失去一切。'], objective: '完成首次顺行试验，为拆解圆车收集未来轨道数据。', reward: 310, total: 32, cuts: [10, 21], spawnGap: 1.56, sequence: ['runner', 'leech', 'wisp', 'shell', 'rust', 'runner'], intel: ['leech', 'wisp', 'clock'], victory: '试验成功证明，循环与彻底遗忘并非仅有的两条路。圆车可以被拆成十二座个人记忆站，让每个人决定携带多少昨日。' },
  12: { chapterId: 4, chapter: '第四章', operation: 'YR-12', title: '亲自抵达明日', location: '圆车终点', story: '终点没有站台，只有一座由恐惧组成的巨大时钟。“明日”说，人类终究会后悔每一次放下，所以它替所有人保存、循环、重演。你下达最后调度：拆解圆车，把记忆归还个人。', quote: '“昨日值得被守护，但明日必须由放下昨日的人亲自抵达。”', broadcast: '这是圆车最后一次逆行。行者全员就位，开始拆解核心。', dialogue: [{ speaker: '小满', text: '我会失去许多人的童年，但能留下今天和大家一起折的纸船。' }, { speaker: '零号', text: '圆车停下后，我也许会消失。请不要为此重新启动它。' }, { speaker: '末代调度员', text: '最终调度确认：把昨天还给每一个人，把明天还给所有人。' }], battleLines: ['“明日”正在投射全部回收兽，维持拆解阵线。', '核心锁解除。调度员，请下达圆车的最后一条指令。'], objective: '击退“明日”本体，完成圆车拆解与记忆归还。', reward: 400, total: 36, cuts: [12, 24], spawnGap: 1.5, sequence: ['wisp', 'runner', 'leech', 'shell', 'rust', 'runner', 'wisp'], intel: ['clock', 'shell', 'leech'], victory: '圆车在第一缕真正的晨光中停下。十二座记忆站向城市开放：有人取回全部昨日，有人只带走一个名字，也有人空手走向明天。你忘记了零号的脸，却记得她留下的选择。昨日失窃案结束，而每个人的时间第一次重新开始。', boss: 'clock' },
  13: { chapterId: 5, chapter: '第五章', operation: 'YR-13', title: '没有时刻表的早班车', location: '东环临时站', story: '圆车停下后的第七天，东环线第一次没有按照旧时刻表发车。市民在站台上争论路线、票价和谁该先上车——这些琐碎分歧比完美循环更吵闹，也更像真正的生活。拆解时逃逸的回收兽却循着人群的新记忆而来。', quote: '“没有时刻表，不代表没有人知道自己要去哪里。”', broadcast: '临时站防线开放。本次敌群以高速与空中目标为主，先稳住路口，再补足远程火力。', dialogue: [{ speaker: '砾灯', text: '轨道可以修，争吵也可以。至少今天没人被迫说同一句话。' }, { speaker: '雾筝', text: '新地图没有回程线。很好，走错了就现场改。' }, { speaker: '零号', text: '这是预先留下的最后一组自动广播。调度员，接下来请相信你自己的判断。' }], battleLines: ['第一波为高速残影，别让它们穿过尚未成形的阵线。', '空忆灯蛾接近；地面阻挡无效，请让狙击守住折返点。'], objective: '保护第一班自主列车，让新产生的今日记忆安全离站。', reward: 330, total: 28, cuts: [9, 19], spawnGap: 1.72, sequence: ['rust', 'runner', 'rust', 'wisp', 'runner', 'rust', 'shell'], intel: ['runner', 'wisp', 'shell'], victory: '早班车晚点了十七分钟，却由乘客共同决定了终点。岑昼在新名字册上写下：“今天的错误不需要回到昨天修正，明天还可以再改一次。”' },
  14: { chapterId: 5, chapter: '第五章', operation: 'YR-14', title: '选择留下的人', location: '第九记忆站', story: '第九记忆站开放个人认领后，有人带走全部过去，也有人把档案永久封存。没有被领取的记忆开始聚成新的兽群：沉积甲壳保存坚硬的事实，空忆灯蛾携带无法说出口的情绪，两者必须用不同的力量处理。', quote: '“归还记忆，也包括尊重一个人不再打开它的决定。”', broadcast: '侦测到高物抗甲壳与高法抗灯蛾交替出现。请同时编入术法与物理远程行者。', dialogue: [{ speaker: '迟鸦', text: '我曾以为知道全部真相的人，天然有权替别人决定。' }, { speaker: '祈修', text: '医生能指出伤口，但要不要揭开纱布，仍然属于伤者。' }, { speaker: '钟离线', text: '站钟已经停了。我们按人的选择开门，不按时间。' }], battleLines: ['沉积甲壳进入折返段：术法攻击能更快击穿它。', '灯蛾与藤兽混编接近；优先清除空中目标，再集中治疗阻挡位。'], objective: '守住记忆认领窗口，分别处理高物抗与高法抗敌群。', reward: 360, total: 31, cuts: [10, 21], spawnGap: 1.64, sequence: ['shell', 'wisp', 'rust', 'leech', 'runner', 'shell', 'wisp', 'rust'], intel: ['shell', 'wisp', 'leech'], victory: '最后一份无人认领的档案属于末代调度员。你没有打开它，只在封面写下：“我不需要完整记得自己，才能为今天的选择负责。”迟鸦替你锁上了档案柜。' },
  15: { chapterId: 5, chapter: '第五章', operation: 'YR-15', title: '第一场真正的雨', location: '无名新站', story: '一场没有被任何旧记录预报的雨落下。城市上空残留的“明日”恐惧随雨凝结，试图重新拼成逆时钟兽。它不再拥有圆车核心，却仍能让人相信：只要未来可能犯错，就应该退回熟悉的昨天。', quote: '“我们不能保证明天更好，只能保证明天由我们亲自经历。”', broadcast: '最终残响将在第三波成形。前两波用于建立费用与防线，不必抢着部署所有行者。', dialogue: [{ speaker: '小满', text: '这场雨不属于任何人的回忆。我想淋一会儿。' }, { speaker: '岑昼', text: '名字册湿了也没关系。今天认识过的人，我今天自己记得。' }, { speaker: '末代调度员', text: '所有行者，守住新站。不是为了保存过去，是为了让普通的明天能够发生。' }], battleLines: ['第二波混合敌群进入长折返段，保留技能应对甲壳与藤兽。', '逆时钟兽残响出现。它已失去循环供能，稳住阻挡并分阶段使用技能。'], objective: '击退“明日”的最后残响，守住城市第一场不可预测的雨。', reward: 450, total: 34, cuts: [11, 23], spawnGap: 1.58, sequence: ['runner', 'rust', 'wisp', 'shell', 'leech', 'rust', 'runner', 'wisp'], intel: ['clock', 'shell', 'wisp', 'leech'], victory: '逆时钟兽在雨里散成无数普通水滴。没有钟声倒转，没有午夜清空，第二天的太阳也没有准时许诺幸福。城市依然醒来，带着昨日留下的困难与自己选择的方向。第五章结束：昨日值得被守护，而明日终于由放下昨日的人亲自抵达。', boss: 'clock' },
};

const stageStoryExtras: Record<StageId, {
  briefing: string; dialogue: { speaker: string; text: string }[]; battleLine: string;
  aftermath: string; aftermathDialogue: { speaker: string; text: string }[];
}> = {
  1: { briefing: '调度室门外放着九杯已经冷掉的茶，其中一杯杯底刻着“零”。岑昼数了两遍人数，仍坚持队伍里应该有第十个人。你没有纠正他，只把那张逆行纸条折进制服内袋。', dialogue: [{ speaker: '回声', text: '广播主机没有通电，可零号的频道正在呼吸。' }, { speaker: '末代调度员', text: '先把今天守住。至于我忘了谁，等列车回来再问。' }], battleLine: '第一街区记忆回流。调度员，你正在想起一扇从未见过的家门。', aftermath: '回到圆车后，你在口袋里摸到一把陌生钥匙。小满说它带着“回家”的味道，可城中没有任何一扇门与它吻合。零号将钥匙编号为 0732，并拒绝解释前七百三十一把去了哪里。', aftermathDialogue: [{ speaker: '小满', text: '如果你忘了家，我可以先替你记着钥匙。' }, { speaker: '岑昼', text: '名字册第一页：调度员没有昨天，但仍然会回家。' }] },
  2: { briefing: '守门人站的值班室每天都会重新摆好早餐。岑昼不记得是谁煮的粥，却熟练地为每个人留出固定位置。唯独靠窗的椅子始终空着，椅背上挂着一件与零号制服同色的旧外套。', dialogue: [{ speaker: '祈修', text: '习惯也是记忆留下的伤疤，身体会替我们保管。' }, { speaker: '岑昼', text: '那就别治好它。至少让我知道，这里曾经有人。' }], battleLine: '守门人站旧记录恢复：岑昼曾在同一天为零号开门四百零九次。', aftermath: '名字册失去的那页从回收兽甲壳中剥落。纸上不是人名，而是一份由你签署的轮班表：每当零号无法继续承受午夜清空，岑昼就负责把她送回核心。', aftermathDialogue: [{ speaker: '岑昼', text: '原来我每天忘记她，是你们故意留下的保护。' }, { speaker: '迟鸦', text: '保护和囚禁，往往只差被保护的人有没有选择。' }] },
  3: { briefing: '第七码头的时刻表写着一班不存在的列车：07:42 抵达，07:42 离开。回声把旧广播倒放，听见无数次“欢迎回来”叠在一起，最后只剩零号压低声音的一句“对不起”。', dialogue: [{ speaker: '雾筝', text: '风筝线在这里绕成了结，说明道路被反复折叠过。' }, { speaker: '回声', text: '第九张票不是乘车凭证，是循环启动许可。签字人是你。' }], battleLine: '站台记忆解封：零号曾在第七百次循环后请求你不要再来找她。', aftermath: '车票记录证明，你每一次醒来都会重新寻找零号，也每一次亲手批准下一轮逆行。纸条“不要让列车顺时针行驶”并非零号所写，而是过去的你留给现在的命令。', aftermathDialogue: [{ speaker: '末代调度员', text: '我留下命令，却没有留下理由。' }, { speaker: '零号', text: '因为理由会让你犹豫，而过去的你最害怕我们抵达明日。' }] },
  4: { briefing: '潮汐仓库的木箱会在无人注视时传出雨声。小满逐一说出箱中记忆的主人，却在最深处那只箱子前失语。箱盖上没有姓名，只有历务局的项目编号“MINOR-0”。', dialogue: [{ speaker: '小满', text: '里面的孩子都在做同一个梦：有人终于记得来接他们。' }, { speaker: '祈修', text: '别急着打开。不是所有想起，都比遗忘更温柔。' }], battleLine: '无主童年正在呼唤拾忆者。小满，记住你可以拒绝成为任何人的替代品。', aftermath: '箱中存放着小满最初的声音。那时她还不会说话，只会模仿每段记忆最后的哭声。零号在观察记录末尾写道：“她不是样本。她第一次笑的时候，计划已经结束了。”', aftermathDialogue: [{ speaker: '小满', text: '所以零号不是制造我的人，是第一个不肯拆掉我的人。' }, { speaker: '迟鸦', text: '她救了你，也把城市的负担留在了你体内。两件事都是真的。' }] },
  5: { briefing: '教室黑板上每天都会出现新的告别词，第二天又被擦成同一句“明天见”。雾筝在操场找到一截断线，线头缠着小满从未拥有过的学生证。照片上的脸不断在全城孩子之间变化。', dialogue: [{ speaker: '萤返', text: '未来信号不是警告，更像有人在反复确认我们有没有收到。' }, { speaker: '雾筝', text: '那就回一盏灯。告诉对面，我们还在路上。' }], battleLine: '未来信号补全：不要把小满交给圆车，也不要替她决定留下哪段童年。', aftermath: '恢复的毕业录像里，孩子们没有唱校歌，而是轮流说出一件愿意忘掉的难过。城市曾经尝试过自愿放下记忆，只是这份方案被历务局判定为“不可控”。', aftermathDialogue: [{ speaker: '小满', text: '原来忘记也可以是自己做的决定。' }, { speaker: '迟鸦', text: '我寻找了十二年的证据，就藏在一群孩子的毕业录像里。' }] },
  6: { briefing: '回收井底没有地面，只有一层层被压实的生日。小满每走一步，年龄就改变一次。她在六岁时抓住你的衣角，在十二岁时松开，最后以现在的模样站到队伍最前方。', dialogue: [{ speaker: '岑昼', text: '名字册不问你从哪里来，只记录你今天站在哪里。' }, { speaker: '小满', text: '那请写：小满，今天选择成为自己。' }], battleLine: '私人记忆生成反应稳定。检测到一段不属于任何市民的全新昨日。', aftermath: '纸船被记忆井承认为独立记录，日期是今天。这意味着小满不再只是旧记忆的拼合体，她创造的新经历拥有与城市历史同等的重量。远处的“明日”第一次表现出愤怒。', aftermathDialogue: [{ speaker: '零号', text: '它害怕的不是我们记得过去，而是我们能创造它无法预知的记忆。' }, { speaker: '小满', text: '那我明天还要再折一只不一样的。' }] },
  7: { briefing: '中央档案桥两侧悬挂着历务局历任研究员的照片。迟鸦的照片仍在最末一格，标注却从“首席研究员”改成了“记忆污染源”。他看了一眼，没有停步。', dialogue: [{ speaker: '砾灯', text: '他们把你的名字抹得挺干净。要我把牌子砸下来吗？' }, { speaker: '迟鸦', text: '留着。一个制度如何称呼反对者，也是值得保存的历史。' }], battleLine: '档案桥公开文件恢复：圆车的能源并非记忆，而是人们失去记忆时产生的恐惧。', aftermath: '迟鸦复制的并非单纯制动密码，而是圆车最初的拆解图。他早已知道第三条道路存在，却隐瞒了它，因为拆解必须得到全城市民逐一授权，远比摧毁列车缓慢。', aftermathDialogue: [{ speaker: '末代调度员', text: '你不是不相信第三条路，你是不相信人们来得及选择。' }, { speaker: '迟鸦', text: '是。我把自己的绝望误认成了所有人的答案。' }] },
  8: { briefing: '制动塔顶层只剩两枚按钮：继续逆行，或永久停车。迟鸦把手放在后者上，却迟迟没有按下。他说自己想看一次调度员在知道代价后，仍然不照旧命令行事。', dialogue: [{ speaker: '岑昼', text: '背叛队伍之前，至少先让队伍听完你的理由。' }, { speaker: '迟鸦', text: '我怕说完以后，你们会原谅我。那会让我更难离开。' }], battleLine: '制动塔倒计时暂停。迟鸦已放开引爆器，但未来裂口仍在扩大。', aftermath: '半枚钥匙落入裂口前传回一帧未来影像：圆车被拆成十二座小站，市民排队签署自己的记忆清单。影像可能是诱饵，却让迟鸦第一次承认，未来也能提供证据。', aftermathDialogue: [{ speaker: '迟鸦', text: '我仍主张结束循环，但不再替别人决定结束的方式。' }, { speaker: '岑昼', text: '很好。明天我会忘记你的背叛，你得亲口再告诉我一次。' }] },
  9: { briefing: '零号车厢没有门把手，因为里面的人从未被允许离开。墙上刻着七百三十二道短痕，每一道旁边都有你的笔迹。最后一道只写了四个字：“这次听她。”', dialogue: [{ speaker: '零号', text: '你每次见到我都先道歉，可真正需要的从来不是道歉。' }, { speaker: '末代调度员', text: '是让你选择，要不要继续成为零号。' }], battleLine: '循环核心权限移交中。警告：前任调度员正在恢复自己的姓名。', aftermath: '零号说出本名时，广播系统自动消去了声音。你只能看见她的口型，却立刻明白：那个名字属于你最早失去的一段人生。你曾承诺，圆车停下后第一个叫她回家。', aftermathDialogue: [{ speaker: '零号', text: '不必记住名字。记住我也曾经可以说“不”。' }, { speaker: '小满', text: '等圆车停下，我会给你取一个只属于明天的新名字。' }] },
  10: { briefing: '两个零号轮流讲述同一段往事：一人在火灾中抓住你的左手，另一人抓住右手。祈修检查后发现，你两只手腕上都留有旧烫伤。循环没有制造假记忆，它把一次选择撕成了两个真实结果。', dialogue: [{ speaker: '回声', text: '如果两段记忆都是真的，声纹鉴定就没有意义。' }, { speaker: '末代调度员', text: '那就不鉴定谁是真人，只判断哪条路允许所有人选择。' }], battleLine: '双重广播停止争夺。两个零号正在共同覆盖圆车的自动驾驶指令。', aftermath: '过去与未来的零号把权限合并成一张空白时刻表。它不再规定圆车逆行或顺行，只允许调度员写下一站。你第一次面对没有前人命令可以服从的控制台。', aftermathDialogue: [{ speaker: '零号·过去', text: '我害怕停下，因为停下以后错误就会真正发生。' }, { speaker: '零号·未来', text: '我害怕继续，因为继续会让所有正确都失去意义。' }] },
  11: { briefing: '顺行试验开始前，每名行者必须写下一段愿意放手的记忆。岑昼交出一本旧名字册，迟鸦交出历务局徽章，小满却只交出一张空白纸——她说自己的过去已经被别人决定得够多了。', dialogue: [{ speaker: '萤返', text: '绿灯不是保证安全，只是允许我们承担前方。' }, { speaker: '砾灯', text: '轨道会断，车轮会磨损。能修的东西，就不必永远停在原地。' }], battleLine: '顺时针距离八百米。城市出现首批自主记忆选择，没有检测到人格坍塌。', aftermath: '试验结束后，岑昼仍记得所有人的名字。不是因为顺行治好了他，而是他只交出了“必须永远记住”的执念。遗忘没有消失，却第一次不再等同于失去。', aftermathDialogue: [{ speaker: '岑昼', text: '我明天可能还是会忘。但今天认识你们，已经完整发生过。' }, { speaker: '零号', text: '这就是圆车一直不肯承认的答案。' }] },
  12: { briefing: '最终调度前，全城收到同一份空白记忆清单。有人写满十页，有人只写一个名字，也有人拒绝提交。圆车没有再替他们补全答案。终点的大钟开始倒数真正的午夜。', dialogue: [{ speaker: '迟鸦', text: '拆解命令一旦执行，没有任何人能把责任推给历史。' }, { speaker: '末代调度员', text: '所以这一次，命令由所有仍愿意前行的人共同签署。' }], battleLine: '十二座个人记忆站全部响应。全城市民授权率不完整——但选择从来不需要整齐一致。', aftermath: '晨光穿过停下的车厢，灰尘第一次朝同一个方向落地。你没有想起零号的脸，也没有想起自己的家，却在空白时刻表背面发现一句新字：“今天不是被偷走的昨日，是我们终于拥有的第一天。”', aftermathDialogue: [{ speaker: '小满', text: '调度员，明天见。是真的明天。' }, { speaker: '末代调度员', text: '列车终到。所有人，请带着自己选择的昨日下车。' }] },
  13: { briefing: '东环临时站的站牌是用旧圆车外壳切成的。砾灯故意没有磨掉背面的循环编号，说新东西不必假装从未有过过去。乘客们用粉笔把目的地写在地上，雨前的风一次次吹乱字迹。', dialogue: [{ speaker: '雾筝', text: '第一张新地图会错很多次。错一次，就多知道一条不能走的路。' }, { speaker: '小满', text: '我想坐到终点，再买一张回来的票。不是循环，是旅行。' }], battleLine: '早班车完成第一次自主变轨。没有预设答案，只有仍在修正的路线。', aftermath: '列车离站后，一名老人发现自己忘带了昨日档案。他没有要求列车倒回去，只笑着说下一班再拿。那是城市第一次把“来不及”当作普通遗憾，而不是需要重启时间的灾难。', aftermathDialogue: [{ speaker: '岑昼', text: '我开始喜欢“下次”这个词了。它不保证重复，只保证还有机会。' }, { speaker: '回声', text: '记录完成：早班车晚点十七分钟，乘客满意度无法统一。' }] },
  14: { briefing: '记忆站门口排着两条队：一条领取过去，一条申请永久封存。迟鸦站在两条队伍之间，回答每个人关于风险的问题，却不再给任何人推荐答案。调度员的档案在最末一柜，封条仍然完整。', dialogue: [{ speaker: '迟鸦', text: '我会提供全部证据，也会承认证据无法替人生活。' }, { speaker: '祈修', text: '今天终于有人可以看完病历，然后决定不接受治疗。' }], battleLine: '认领窗口保持开放。甲壳展开硬化时切换术法，灯蛾接近时交给物理远程。', aftermath: '当天共有三百一十二人领回记忆，九十七人选择封存，另有四十人把决定推迟到明天。记忆站没有把“尚未决定”判定为错误，城市也没有因此停止。', aftermathDialogue: [{ speaker: '钟离线', text: '旧站钟最讨厌等待。新站允许人慢一点。' }, { speaker: '末代调度员', text: '把我的档案也列为延期。今天的我还有今天要做。' }] },
  15: { briefing: '雨滴落在拆下来的圆车核心上，敲出一段从未录入档案的节奏。小满伸手确认这不是任何人的旧记忆。天空中的恐惧仍在聚合，但它已经无法借用全城的昨日，只能以最后一只逆时钟兽的形状落到轨道。', dialogue: [{ speaker: '岑昼', text: '今天的名字我都记得。明天若忘了，我会重新问。' }, { speaker: '小满', text: '那我明天要告诉你：我们一起淋过第一场真正的雨。' }], battleLine: '逆时钟兽低于半数强度后会加速。控制技能请分开使用，不要一次全部交出。', aftermath: '战后没有盛大的纪念仪式。市民收起伞去上班，孩子踩进水洼，检修员抱怨新站漏雨。调度员忽然明白，所谓抵达明日，不是一座完美终点，而是人们终于可以继续处理这些不会被时间替他们抹去的小事。', aftermathDialogue: [{ speaker: '迟鸦', text: '我曾想摧毁历史，以为那样就能结束痛苦。' }, { speaker: '末代调度员', text: '现在我们保存选择。至于历史，让每个人决定带走多少。' }, { speaker: '小满', text: '调度员，雨停了。我们去看看明天长什么样。' }] },
};

const chapterInterludes = [
  { chapterId: 1, unlock: 1, code: 'INTERLUDE 01', title: '午夜以前的名字', body: ['圆车餐车里有一面只在午夜前显字的黑板。岑昼每天都把队友名字抄上去，零点之后再从头学习。某一次，他在最下方发现一句并非自己笔迹的话：“不要因为会忘记，就假装没有爱过。”', '回声比对字迹，确认留言来自循环开始前的岑昼。那时他的身体尚未停在昨天，他却已经知道自己将付出什么代价。'], dialogue: [{ speaker: '岑昼', text: '过去的我比现在勇敢吗？' }, { speaker: '祈修', text: '不。他只是把勇气留给了每天醒来的你。' }] },
  { chapterId: 2, unlock: 4, code: 'INTERLUDE 02', title: '小满的一百个生日', body: ['圆车为小满举办生日时，八名行者给出了八个不同日期。那些日期都来自她体内某段童年最幸福的一天。小满没有挑选任何一个，只把今天圈了起来。', '她邀请众人写下“从未发生但希望记住的事”。这些虚构记忆在午夜后没有消失，反而留在纸上，证明记忆不仅属于过去，也可以是人对未来作出的约定。'], dialogue: [{ speaker: '小满', text: '如果生日是开始成为自己的那天，那我今天刚刚出生。' }, { speaker: '迟鸦', text: '历务局不会承认一段虚构记忆。' }, { speaker: '零号', text: '那就让明天替她证明。' }] },
  { chapterId: 3, unlock: 7, code: 'INTERLUDE 03', title: '迟鸦没有寄出的辞呈', body: ['迟鸦的研究日志里夹着一封写了十二年的辞呈。他每次准备离开历务局，就会想起仍有人被困在圆车核心，于是把辞呈重新折好。后来他终于明白，留下并没有让制度变好，只让自己越来越像它。', '他把辞呈交给调度员保管，要求真结局后公开全部研究，包括那些由他亲自批准的失败试验。保存历史不该只保存自己的正确。'], dialogue: [{ speaker: '迟鸦', text: '如果城市原谅我，请确保他们先看完所有证据。' }, { speaker: '砾灯', text: '放心。你的错一页都不会少，你做对的也一样。' }] },
  { chapterId: 4, unlock: 10, code: 'INTERLUDE 04', title: '停站之后', body: ['众人讨论圆车停下后要做什么。雾筝想重新绘制会变化的城市地图，祈修准备开一间允许病人决定是否保留伤疤的诊所，砾灯坚持先修好每个普通站台的雨棚。', '没有人能保证这些计划会实现。恰恰因为未来不再被循环保存，承诺才重新有了重量。零号安静地听完，在广播末尾留下一秒没有内容的空白。那一秒属于任何尚未决定的明天。'], dialogue: [{ speaker: '萤返', text: '下一班车没有时刻表。' }, { speaker: '回声', text: '那我就记录它真正抵达的时间。' }, { speaker: '零号', text: '很好。以后不必准时回到昨天。' }] },
  { chapterId: 5, unlock: 13, code: 'INTERLUDE 05', title: '普通的一天', body: ['圆车停下一个月后，八名行者约定在东环站见面。岑昼迟到了，雾筝走错站，迟鸦把礼物忘在档案室，小满则记得每个人答应带什么。没有循环把聚会恢复成完美版本，他们只好在附近买了不太好吃的面包。', '零号的自动广播在这天耗尽了最后一段录音。末尾没有告别，只有一声像是推开门的轻响。众人没有寻找声音来自哪里，而是在站台长椅上给她留了一个位置。'], dialogue: [{ speaker: '小满', text: '如果她没有来，蛋糕也要切成九份吗？' }, { speaker: '岑昼', text: '切。留下位置，不等于要求谁必须回来。' }, { speaker: '迟鸦', text: '这大概是我们学会的最后一课。' }] },
] as const;

const monsters: Record<EnemyKind, { name: string; code: string; art: string; trait: string; physicalResistance: number; arcaneResistance: number }> = {
  rust: { name: '锈忆兽', code: '锈', art: '/monsters/rust-v1.png', trait: '防护较低；击退后散出可回收残片，返还 1 点部署费用。', physicalResistance: .18, arcaneResistance: .12 },
  runner: { name: '急行残影', code: '迅', art: '/monsters/runner-v1.png', trait: '第二关起入场短暂冲刺；防护很低，提前部署先锋即可拦截。', physicalResistance: .06, arcaneResistance: .08 },
  shell: { name: '沉积甲壳', code: '甲', art: '/monsters/shell-v1.png', trait: '未被阻挡时展开减伤护壳；阻挡或停摆可破壳，术法攻击仍最有效。', physicalResistance: .68, arcaneResistance: .1 },
  wisp: { name: '空忆灯蛾', code: '空', art: '/monsters/wisp-v1.png', trait: '无法被阻挡，会沿途空袭附近行者；法抗很高，狙击最有效。', physicalResistance: .08, arcaneResistance: .66 },
  leech: { name: '食忆藤兽', code: '食', art: '/monsters/leech-v1.png', trait: '攻击时汲取行者记忆恢复生命，优先集火或使用控制打断。', physicalResistance: .36, arcaneResistance: .34 },
  clock: { name: '逆时钟兽', code: '逆', art: '/monsters/clock-v1.png', trait: '“明日”的化身；第五章残响半血后加速，建议分段使用控制技能。', physicalResistance: .52, arcaneResistance: .5 },
};

const operators: Record<OperatorId, {
  name: string; code: string; role: string; cost: number; hp: number; damage: number;
  range: number; ground: boolean; block: number; attackInterval: number; color: string; skill: string; skillDesc: string;
  identity: string; bio: string; trait: string; damageType: 'physical' | 'arcane' | 'heal'; art?: string; sprite?: number;
}> = {
  lith: { name: '岑昼', code: '岑', role: '近卫 / 阻挡 1', identity: '行者队长 · 守门人', bio: '身体一半停在昨天。伤口每天复原，队友却每天从记忆里消失；他靠一本名字册重新认识所有人。', trait: '近卫：稳定的近距离物理输出', cost: 9, hp: 720, damage: 88, range: 1, ground: true, block: 1, attackInterval: 1.05, color: '#d6ef36', skill: '昨日重演', skillDesc: '生命回溯至 4 秒前；6 秒内同时攻击所有阻挡目标，并将伤害转为治疗', damageType: 'physical', art: '/operators/lith-v2.png' },
  kite: { name: '雾筝', code: '雾', role: '狙击 / 远程', identity: '轨道测绘师 · 狙击', bio: '把旧城区每条消失的街道系成风筝线；只要线还在，圆车就知道昨日曾通往哪里。', trait: '狙击：远程物理攻击，优先高速敌人', cost: 11, hp: 420, damage: 72, range: 3, ground: false, block: 0, attackInterval: 1.2, color: '#38d7e8', skill: '穿云索', skillDesc: '标记范围内最接近终点的敌人 10 秒；攻击优先锁定标记并穿透 75% 物抗', damageType: 'physical', art: '/operators/kite-v2.png' },
  bell: { name: '迟鸦', code: '鸦', role: '术师 / 法术', identity: '历务局研究员 · 逆行者', bio: '相信历史只会复制痛苦，主张摧毁圆车。仍与行者同行，却把每次胜利都记录成一次延迟的背叛。', trait: '术师：法术攻击无视敌方护甲', cost: 14, hp: 460, damage: 64, range: 2, ground: false, block: 0, attackInterval: 1.55, color: '#9d68e7', skill: '零点否决', skillDesc: '范围内敌人沿轨道倒退，并陷入 2.8 秒停摆', damageType: 'arcane', art: '/operators/bell-v2.png' },
  mend: { name: '祈修', code: '修', role: '医疗 / 恢复', identity: '记忆修复师 · 医疗', bio: '以车票碎屑缝合伤口，也替伤者保管那些不敢再想起的昨日。', trait: '医疗：优先治疗生命比例最低的单个行者', cost: 12, hp: 400, damage: 82, range: 3, ground: false, block: 0, attackInterval: 1.35, color: '#75e6b0', skill: '昨日补缀', skillDesc: '为攻击范围内全部行者缝合可吸收伤害的记忆护盾', damageType: 'heal', art: '/operators/mend-v2.png' },
  flare: { name: '小满', code: '满', role: '先锋 / 阻挡 1', identity: '拾忆者 · 童年拼合体', bio: '能从回收兽体内取出未消化的记忆。她并非某个孩子，而是全城遗失童年拼成的一个人。', trait: '先锋：攻击更快，每次命中回复 1 点部署费用', cost: 7, hp: 560, damage: 66, range: 1, ground: true, block: 1, attackInterval: .82, color: '#f2b94c', skill: '童年回收', skillDesc: '立即获得 10 点费用，并向范围内至多 3 名敌人投掷无视一半物抗的记忆瓶', damageType: 'physical', art: '/operators/flare-v2.png' },
  anchor: { name: '砾灯', code: '砾', role: '重装 / 阻挡 2', identity: '轨道检修员 · 重装', bio: '她用圆轨锤逐节敲醒被遗忘的轨道；每一簇火花，都是旧城尚未熄灭的一盏灯。', trait: '重装：阻挡 2 名敌人，受到伤害降低 30%', cost: 13, hp: 1180, damage: 48, range: 1, ground: true, block: 2, attackInterval: 1.55, color: '#ff7a32', skill: '逆向超载', skillDesc: '砸击周围轨道，令附近敌人停摆 3 秒，并获得最大生命 35% 的屏障', damageType: 'physical', art: '/operators/anchor-v2.png' },
  loom: { name: '萤返', code: '萤', role: '辅助 / 法术', identity: '信号跑者 · 辅助', bio: '沿逆行轨道追赶那些将熄的信号，用双棒把人们不敢回望的昨日重新点亮。', trait: '辅助：信号脉冲使命中敌人短暂减速 35%', cost: 10, hp: 450, damage: 55, range: 2, ground: false, block: 0, attackInterval: 1.25, color: '#ffd126', skill: '引火回路', skillDesc: '展开 10 秒信号场，范围内敌人持续减速；每次攻击连锁至 3 个目标', damageType: 'arcane', art: '/operators/loom-v2.png' },
  echo: { name: '回声', code: '回', role: '医疗 / 广域', identity: '声像档案员 · 医疗', bio: '午夜后失去了本名，只能复述他人的最后一句话；零号因此称他为回声。', trait: '广域医疗：每次同时治疗最多 2 名行者', cost: 15, hp: 440, damage: 68, range: 3, ground: false, block: 0, attackInterval: 1.7, color: '#61d7bd', skill: '复写脉冲', skillDesc: '把最健康行者的生命比例复写给两名重伤者，并令全队再部署倒计时减少 8 秒', damageType: 'heal', art: '/operators/echo-v2.png' },
  clockline: { name: '钟离线', code: '钟', role: '群法师 / 范围', identity: '站钟档案员 · 群法师', bio: '把被抹去站台的钟声编进破损时刻表。每次法阵爆裂，附近的回收兽都会听见一段不属于自己的昨日。', trait: '群法师：法术命中后对目标附近敌人造成范围伤害', cost: 17, hp: 430, damage: 74, range: 2, ground: false, block: 0, attackInterval: 2.25, color: '#52e4ef', skill: '离站钟鸣', skillDesc: '冻结范围内敌人 4 秒；8 秒内每次钟爆覆盖整个攻击范围', damageType: 'arcane', art: '/operators/clockline-v1.png' },
};

const levelHp = (opId: OperatorId, level: number) => Math.round(operators[opId].hp * (1 + (level - 1) * .12));
const levelAttack = (opId: OperatorId, level: number) => Math.round(operators[opId].damage * (1 + (level - 1) * .1));
const upgradeCost = (level: number) => level * 55 + (level >= 5 ? 35 : 0);
const trainingPhase = (level: number) => level >= 10 ? '记忆同调 III' : level >= 6 ? '记忆同调 II' : '基础同调 I';

const initialState: GameState = {
  mode: 'title', cost: 12, lives: 3, killed: 0, spawned: 0, elapsed: 0,
  nextSpawn: .1, selected: null, selectedUnit: null, speed: 1, units: [], enemies: [],
  redeploy: { lith: 0, kite: 0, bell: 0, mend: 0, flare: 0, anchor: 0, loom: 0, echo: 0, clockline: 0 },
  message: '零号广播：请部署行者，守住旧城区的昨日。',
  stageId: 1, levels: defaultLevels, runId: 0, squad: ['lith', 'kite', 'bell', 'mend', 'flare', 'anchor'],
};

type Action =
  | { type: 'LOBBY' } | { type: 'PREPARE'; stageId: StageId; levels: OperatorLevels; squad: OperatorId[] } | { type: 'BEGIN'; stageId: StageId; levels: OperatorLevels; squad: OperatorId[]; runId: number } | { type: 'START' } | { type: 'TICK'; dt: number }
  | { type: 'SELECT'; opId: OperatorId } | { type: 'DEPLOY'; cell: number; opId?: OperatorId; direction?: Direction }
  | { type: 'SELECT_UNIT'; id: number } | { type: 'CLEAR_UNIT' } | { type: 'SKILL' } | { type: 'RETREAT' }
  | { type: 'PAUSE' } | { type: 'SPEED' } | { type: 'RESTART' } | { type: 'TITLE' };

function directionName(direction: Direction) {
  return { up: '上', right: '右', down: '下', left: '左' }[direction];
}

type OperatorSoundLayer = { src: string; volume: number; rate: number; delay?: number };

const operatorSoundSettings: Record<OperatorId, OperatorSoundLayer[]> = {
  lith: [
    { src: '/audio/operators/combat-sword-swing.ogg', volume: .66, rate: .96 },
    { src: '/audio/operators/combat-sword-impact.ogg', volume: .7, rate: .94, delay: 150 },
  ],
  kite: [{ src: '/audio/operators/combat-rifle.mp3', volume: .64, rate: 1.08 }],
  bell: [{ src: '/audio/operators/combat-magic-heavy.ogg', volume: .58, rate: .92 }],
  mend: [{ src: '/audio/operators/combat-magic-light.ogg', volume: .36, rate: 1.14 }],
  flare: [
    { src: '/audio/operators/combat-sword-swing.ogg', volume: .5, rate: 1.18 },
    { src: '/audio/operators/combat-sword-impact.ogg', volume: .48, rate: 1.12, delay: 105 },
  ],
  anchor: [
    { src: '/audio/operators/combat-sword-swing.ogg', volume: .62, rate: .76 },
    { src: '/audio/operators/combat-sword-impact.ogg', volume: .86, rate: .72, delay: 210 },
  ],
  loom: [{ src: '/audio/operators/combat-magic-light.ogg', volume: .45, rate: .92 }],
  echo: [{ src: '/audio/operators/combat-magic-light.ogg', volume: .34, rate: .72 }],
  clockline: [{ src: '/audio/operators/combat-magic-heavy.ogg', volume: .62, rate: .78 }],
};

function playOperatorAttackSound(
  pool: Map<string, HTMLAudioElement>,
  opId: OperatorId,
  activeSounds: Set<HTMLAudioElement>,
  timers: Set<number>,
) {
  for (const layer of operatorSoundSettings[opId]) {
    const playLayer = () => {
      const template = pool.get(layer.src);
      if (!template) return;
      const sound = template.cloneNode(true) as HTMLAudioElement;
      sound.volume = layer.volume;
      sound.playbackRate = layer.rate * (.97 + Math.random() * .06);
      activeSounds.add(sound);
      const release = () => activeSounds.delete(sound);
      sound.addEventListener('ended', release, { once: true });
      sound.addEventListener('error', release, { once: true });
      void sound.play().catch(release);
    };
    if (layer.delay) {
      const timer = window.setTimeout(() => {
        timers.delete(timer);
        playLayer();
      }, layer.delay);
      timers.add(timer);
    } else playLayer();
  }
}

function isInAttackRange(source: Pick<Unit, 'opId' | 'cell' | 'direction'>, targetCell: number) {
  const op = operators[source.opId];
  const sourceRow = Math.floor(source.cell / COLS);
  const sourceCol = source.cell % COLS;
  const targetRow = Math.floor(targetCell / COLS);
  const targetCol = targetCell % COLS;
  const dr = targetRow - sourceRow;
  const dc = targetCol - sourceCol;
  const forward = source.direction === 'up' ? -dr : source.direction === 'down' ? dr : source.direction === 'left' ? -dc : dc;
  const lateral = source.direction === 'up' || source.direction === 'down' ? dc : dr;
  return forward >= 0 && forward <= op.range && Math.abs(lateral) <= (op.ground ? 0 : 1);
}

function pathCoordinates(pos: number, stageId: StageId, route = 0) {
  const path = stagePath(stageId, route);
  const from = path[Math.min(path.length - 1, Math.floor(pos))];
  const to = path[Math.min(path.length - 1, Math.ceil(pos))];
  const f = pos - Math.floor(pos);
  return {
    row: Math.floor(from / COLS) * (1 - f) + Math.floor(to / COLS) * f,
    col: (from % COLS) * (1 - f) + (to % COLS) * f,
  };
}

function enemyInUnitRange(unit: Pick<Unit, 'opId' | 'cell' | 'direction'>, enemy: Enemy, stageId: StageId) {
  const path = stagePath(stageId, enemy.route);
  return isInAttackRange(unit, path[Math.min(path.length - 1, Math.round(enemy.pos))]);
}

function enemyDistanceToUnit(unit: Pick<Unit, 'cell'>, enemy: Enemy, stageId: StageId) {
  const point = pathCoordinates(enemy.pos, stageId, enemy.route);
  return Math.hypot(Math.floor(unit.cell / COLS) - point.row, unit.cell % COLS - point.col);
}

function enemyProgress(enemy: Enemy, stageId: StageId) {
  return enemy.pos / Math.max(1, stagePath(stageId, enemy.route).length - 1);
}

function makeEnemy(index: number, stageId: StageId): Enemy {
  const stage = stages[stageId];
  const routes = stageRoutes(stageId);
  const wave = index < stage.cuts[0] ? 1 : index < stage.cuts[1] ? 2 : 3;
  const kind: EnemyKind = stage.boss && index === stage.total - 1 ? stage.boss : stage.sequence[index % stage.sequence.length];
  const stageScale = 1 + Math.min(stageId - 1, 11) * .035 + Math.max(0, stageId - 12) * .015;
  const base = {
    rust: { hp: 235 + wave * 42, speed: .38, attack: 27, attackInterval: 1.5 },
    runner: { hp: 175 + wave * 28, speed: .62, attack: 20, attackInterval: 1.05 },
    shell: { hp: 390 + wave * 65, speed: .26, attack: 39, attackInterval: 2.1 },
    wisp: { hp: 155 + wave * 27, speed: .52, attack: 14, attackInterval: 2.2 },
    leech: { hp: 320 + wave * 55, speed: .3, attack: 30, attackInterval: 1.65 },
    clock: { hp: 1900, speed: .19, attack: 58, attackInterval: 1.85 },
  }[kind];
  const table = { ...base, hp: Math.round(base.hp * stageScale), attack: Math.round(base.attack * stageScale) };
  const route = stage.boss && index === stage.total - 1 ? (stageId + index) % routes.length : index % routes.length;
  return { id: Date.now() + index, kind, route, pos: 0, maxHp: table.hp, hp: table.hp, speed: table.speed, attack: table.attack, attackInterval: table.attackInterval, attackCooldown: .2, attackFx: 0, slowTimer: 0, stunTimer: 0, markTimer: 0, hitFx: 0, attacking: false, physicalResistance: monsters[kind].physicalResistance, arcaneResistance: monsters[kind].arcaneResistance };
}

function gameReducer(state: GameState, action: Action): GameState {
  if (action.type === 'LOBBY') return { ...initialState, mode: 'lobby' };
  if (action.type === 'PREPARE') return { ...initialState, mode: 'formation', stageId: action.stageId, levels: action.levels, squad: action.squad };
  if (action.type === 'BEGIN') return { ...initialState, mode: 'briefing', stageId: action.stageId, levels: action.levels, squad: action.squad, runId: action.runId, message: `零号广播：${stages[action.stageId].broadcast}` };
  if (action.type === 'TITLE') return { ...initialState };
  if (action.type === 'RESTART') return { ...initialState, mode: 'briefing', stageId: state.stageId, levels: state.levels, squad: state.squad, runId: Date.now(), message: `零号广播：${stages[state.stageId].broadcast}` };
  if (action.type === 'START') return { ...state, mode: 'running', message: `零号广播：${stages[state.stageId].broadcast}` };
  if (action.type === 'PAUSE') return { ...state, mode: state.mode === 'paused' ? 'running' : 'paused' };
  if (action.type === 'SPEED') return { ...state, speed: state.speed === 1 ? 2 : 1 };
  if (action.type === 'SELECT') return state.redeploy[action.opId] > 0 ? state : { ...state, selected: action.opId, selectedUnit: null, message: `已选择 ${operators[action.opId].name}` };
  if (action.type === 'SELECT_UNIT') return { ...state, selectedUnit: action.id, selected: null };
  if (action.type === 'CLEAR_UNIT') return state.selectedUnit === null ? state : { ...state, selectedUnit: null };

  if (action.type === 'DEPLOY') {
    const opId = action.opId || state.selected;
    if (!opId || state.units.some((u) => u.cell === action.cell)) return state;
    const op = operators[opId];
    if (state.redeploy[opId] > 0) return { ...state, selected: null, message: `${op.name} 仍在重整，${Math.ceil(state.redeploy[opId])} 秒后可再次部署。` };
    if (op.ground !== new Set(stageRoutes(state.stageId).flat()).has(action.cell)) return { ...state, message: op.ground ? '近卫只能部署在轨道上。' : '远程行者只能部署在高台上。' };
    if (state.units.some((u) => u.opId === opId)) return { ...state, message: '该行者已在场。' };
    if (state.cost < op.cost) return { ...state, message: '部署费用不足。' };
    const id = Date.now();
    const level = state.levels[opId] || 1;
    const maxHp = Math.round(op.hp * (1 + (level - 1) * .12));
    return {
      ...state, cost: state.cost - op.cost, selected: null, selectedUnit: id,
      units: [...state.units, { id, opId, cell: action.cell, hp: maxHp, maxHp, shield: 0, rewindHp: maxHp, rewindTimer: 4, skill: 0, skillTimer: 0, attackCooldown: .15, attackFx: 0, skillFx: 0, hurtFx: 0, healFx: 0, direction: action.direction || 'right', level, attackTargetRow: null, attackTargetCol: null }],
      message: `${op.name} · Lv.${level} 已朝${directionName(action.direction || 'right')}部署。`,
    };
  }

  if (action.type === 'SKILL') {
    const chosen = state.units.find((u) => u.id === state.selectedUnit);
    if (!chosen || chosen.skill < 100) return state;
    const op = operators[chosen.opId];
    const armSkill = (units: Unit[], duration: number) => units.map((unit) => unit.id === chosen.id ? { ...unit, skill: 0, skillTimer: duration, skillFx: 1.4 } : unit);
    let units = state.units;
    let enemies = state.enemies;
    let cost = state.cost;
    const redeploy = { ...state.redeploy };
    let message = `${op.skill} 已启动。`;

    if (chosen.opId === 'lith') {
      units = armSkill(units.map((unit) => unit.id === chosen.id ? { ...unit, hp: Math.max(unit.hp, unit.rewindHp) } : unit), 6);
      message = `昨日重演：岑昼回到 4 秒前的生命状态，开始同时反击阻挡目标。`;
    } else if (chosen.opId === 'kite') {
      const target = enemies.filter((enemy) => enemyInUnitRange(chosen, enemy, state.stageId)).sort((a, b) => enemyProgress(b, state.stageId) - enemyProgress(a, state.stageId))[0];
      enemies = enemies.map((enemy) => enemy.id === target?.id ? { ...enemy, markTimer: 10 } : enemy);
      units = armSkill(units, 1.4);
      message = target ? `穿云索：${monsters[target.kind].name} 已被定标，雾筝将优先追踪并穿透其物抗。` : `穿云索已展开，但当前范围内没有可标记目标。`;
    } else if (chosen.opId === 'bell') {
      enemies = enemies.map((enemy) => enemyInUnitRange(chosen, enemy, state.stageId) ? { ...enemy, pos: Math.max(0, enemy.pos - 1.25), stunTimer: Math.max(enemy.stunTimer, 2.8), attacking: false } : enemy);
      units = armSkill(units, 1.4);
      message = `零点否决：范围内回收兽的时间被撤销，沿轨道倒退并停摆。`;
    } else if (chosen.opId === 'mend') {
      units = armSkill(units.map((unit) => isInAttackRange(chosen, unit.cell) ? { ...unit, shield: unit.shield + Math.round(op.damage * (1 + (chosen.level - 1) * .1) * 2.4), healFx: .7 } : unit), 1.4);
      message = `昨日补缀：范围内行者已获得记忆护盾。`;
    } else if (chosen.opId === 'flare') {
      const targets = enemies.filter((enemy) => enemyInUnitRange(chosen, enemy, state.stageId)).sort((a, b) => enemyProgress(b, state.stageId) - enemyProgress(a, state.stageId)).slice(0, 3);
      const targetIds = new Set(targets.map((enemy) => enemy.id));
      const raw = op.damage * (1 + (chosen.level - 1) * .1) * 1.6;
      enemies = enemies.map((enemy) => targetIds.has(enemy.id) ? { ...enemy, hp: enemy.hp - raw * (1 - enemy.physicalResistance * .5), hitFx: .45 } : enemy);
      cost = Math.min(99, cost + 10);
      units = armSkill(units, 1.4);
      message = `童年回收：取回 10 点费用，${targets.length ? `记忆瓶命中 ${targets.length} 个目标` : '记忆瓶等待下次目标'}。`;
    } else if (chosen.opId === 'anchor') {
      enemies = enemies.map((enemy) => enemyDistanceToUnit(chosen, enemy, state.stageId) <= 1.65 ? { ...enemy, stunTimer: Math.max(enemy.stunTimer, 3), attacking: false } : enemy);
      units = armSkill(units.map((unit) => unit.id === chosen.id ? { ...unit, shield: unit.shield + Math.round(unit.maxHp * .35) } : unit), 1.4);
      message = `逆向超载：周围轨道震荡，敌人停摆；砾灯获得紧急屏障。`;
    } else if (chosen.opId === 'loom') {
      units = armSkill(units, 10);
      message = `引火回路：信号场展开 10 秒，场内回收兽减速，攻击将发生连锁。`;
    } else if (chosen.opId === 'echo') {
      const healthiestRatio = Math.max(...units.map((unit) => unit.hp / unit.maxHp));
      const wounded = [...units].sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp).slice(0, 2);
      const woundedIds = new Set(wounded.map((unit) => unit.id));
      units = armSkill(units.map((unit) => woundedIds.has(unit.id) ? { ...unit, hp: Math.max(unit.hp, unit.maxHp * healthiestRatio), healFx: .8 } : unit), 1.4);
      (Object.keys(redeploy) as OperatorId[]).forEach((opId) => { redeploy[opId] = Math.max(0, redeploy[opId] - 8); });
      message = `复写脉冲：最完整的心跳已复写给重伤者，全队再部署时间减少 8 秒。`;
    } else {
      enemies = enemies.map((enemy) => enemyInUnitRange(chosen, enemy, state.stageId) ? { ...enemy, stunTimer: Math.max(enemy.stunTimer, 4), attacking: false } : enemy);
      units = armSkill(units, 8);
      message = `离站钟鸣：范围内时间冻结，后续钟爆将覆盖整个攻击范围。`;
    }
    return { ...state, units, enemies, cost, redeploy, message };
  }

  if (action.type === 'RETREAT') {
    const chosen = state.units.find((u) => u.id === state.selectedUnit);
    if (!chosen) return state;
    return { ...state, cost: Math.min(99, state.cost + Math.floor(operators[chosen.opId].cost / 2)), units: state.units.filter((u) => u.id !== chosen.id), selectedUnit: null, message: `${operators[chosen.opId].name} 已撤回。` };
  }

  if (action.type !== 'TICK' || state.mode !== 'running') return state;
  const dt = action.dt;
  let elapsed = state.elapsed + dt;
  let message = state.message;
  const stage = stages[state.stageId];
  let spawned = state.spawned;
  let nextSpawn = state.nextSpawn;
  const redeploy = { ...state.redeploy };
  (Object.keys(redeploy) as OperatorId[]).forEach((opId) => { redeploy[opId] = Math.max(0, redeploy[opId] - dt); });
  let enemies = state.enemies.map((e) => ({ ...e, attackCooldown: Math.max(0, e.attackCooldown - dt), attackFx: Math.max(0, e.attackFx - dt), slowTimer: Math.max(0, e.slowTimer - dt), stunTimer: Math.max(0, e.stunTimer - dt), markTimer: Math.max(0, e.markTimer - dt), hitFx: Math.max(0, e.hitFx - dt) }));
  let units = state.units.map((u) => {
    const recordNow = u.rewindTimer - dt <= 0;
    return { ...u, rewindHp: recordNow ? u.hp : u.rewindHp, rewindTimer: recordNow ? 4 : u.rewindTimer - dt, skill: Math.min(100, u.skill + dt * 6), skillTimer: Math.max(0, u.skillTimer - dt), attackCooldown: Math.max(0, u.attackCooldown - dt), attackFx: Math.max(0, u.attackFx - dt), skillFx: Math.max(0, u.skillFx - dt), hurtFx: Math.max(0, u.hurtFx - dt), healFx: Math.max(0, u.healFx - dt) };
  });

  if (state.elapsed < 4 && elapsed >= 4) message = `零号广播：${stage.objective}`;
  if (state.elapsed < 18 && elapsed >= 18) message = `零号广播：${stage.battleLines[0]}`;
  if (state.elapsed < 32 && elapsed >= 32) message = `零号广播：${stage.battleLines[1]}`;
  if (state.elapsed < 45 && elapsed >= 45) message = `零号广播：${stageStoryExtras[state.stageId].battleLine}`;

  if (spawned < stage.total && elapsed >= nextSpawn) {
    enemies.push(makeEnemy(spawned, state.stageId));
    spawned += 1;
    const waveGap = spawned === stage.cuts[0] || spawned === stage.cuts[1] ? 4.5 : 0;
    nextSpawn += stage.spawnGap + waveGap;
  }

  const blockers = units.filter((u) => operators[u.opId].ground);
  const blockedBy = new Map<number, Unit>();
  const blockedCounts = new Map<number, number>();
  for (const enemy of enemies.sort((a, b) => enemyProgress(b, state.stageId) - enemyProgress(a, state.stageId))) {
    if (enemy.kind === 'wisp') continue;
    const path = stagePath(state.stageId, enemy.route);
    const cell = path[Math.min(path.length - 1, Math.round(enemy.pos))];
    const blocker = blockers.find((u) => {
      const blockCapacity = operators[u.opId].block + (u.opId === 'lith' && u.skillTimer > 0 ? 1 : 0);
      return u.cell === cell && (blockedCounts.get(u.id) || 0) < blockCapacity;
    });
    if (blocker) {
      blockedBy.set(enemy.id, blocker);
      blockedCounts.set(blocker.id, (blockedCounts.get(blocker.id) || 0) + 1);
    }
  }

  const wispTargets = new Map<number, Unit>();
  for (const enemy of enemies) {
    if (enemy.kind !== 'wisp') continue;
    const point = pathCoordinates(enemy.pos, state.stageId, enemy.route);
    const target = units
      .map((unit) => ({ unit, distance: Math.hypot(Math.floor(unit.cell / COLS) - point.row, unit.cell % COLS - point.col) }))
      .filter(({ distance }) => distance <= 1.65)
      .sort((a, b) => a.unit.hp / a.unit.maxHp - b.unit.hp / b.unit.maxHp)[0]?.unit;
    if (target) wispTargets.set(enemy.id, target);
  }

  const unitDamage = new Map<number, number>();
  enemies = enemies.map((enemy) => {
    if (enemy.hp <= 0) return { ...enemy, attacking: false };
    const blocker = blockedBy.get(enemy.id) || wispTargets.get(enemy.id);
    if (enemy.stunTimer > 0) return { ...enemy, attacking: false };
    if (blocker) {
      const strikes = enemy.attackCooldown <= 0;
      if (strikes) unitDamage.set(blocker.id, (unitDamage.get(blocker.id) || 0) + enemy.attack);
      const healed = strikes && enemy.kind === 'leech' ? enemy.attack * .65 : 0;
      const frenzy = state.stageId >= 15 && enemy.kind === 'clock' && enemy.hp <= enemy.maxHp * .5;
      return { ...enemy, hp: Math.min(enemy.maxHp, enemy.hp + healed), attacking: true, attackCooldown: strikes ? enemy.attackInterval * (frenzy ? .82 : 1) : enemy.attackCooldown, attackFx: strikes ? .86 : enemy.attackFx };
    }
    const insideSignalField = units.some((unit) => unit.opId === 'loom' && unit.skillTimer > 0 && enemyInUnitRange(unit, enemy, state.stageId));
    const runnerSprint = state.stageId >= 2 && enemy.kind === 'runner' && enemy.pos < 2.2;
    const clockFrenzy = state.stageId >= 15 && enemy.kind === 'clock' && enemy.hp <= enemy.maxHp * .5;
    const mechanicSpeed = runnerSprint ? (state.stageId >= 13 ? 1.35 : 1.15) : clockFrenzy ? 1.22 : 1;
    const speedMultiplier = (insideSignalField ? .22 : enemy.slowTimer > 0 ? .65 : 1) * mechanicSpeed;
    return { ...enemy, attacking: false, pos: enemy.pos + enemy.speed * speedMultiplier * dt };
  });
  units = units.map((unit) => {
    const incoming = (unitDamage.get(unit.id) || 0) * (unit.opId === 'anchor' ? .7 : 1);
    const absorbed = Math.min(unit.shield, incoming);
    const damage = incoming - absorbed;
    return { ...unit, shield: unit.shield - absorbed, hp: unit.hp - damage, hurtFx: incoming > 0 ? .32 : unit.hurtFx };
  });
  const fallenUnits = units.filter((unit) => unit.hp <= 0);
  fallenUnits.forEach((unit) => { redeploy[unit.opId] = 12; });
  if (fallenUnits.length) message = `零号广播：${fallenUnits.map((unit) => operators[unit.opId].name).join('、')} 已撤离，12 秒后可重新部署。`;
  units = units.filter((unit) => unit.hp > 0);

  const damageTaken = new Map<number, number>();
  const healing = new Map<number, number>();
  const slowedEnemies = new Set<number>();
  let costFromTraits = 0;
  for (const unit of units) {
    const op = operators[unit.opId];
    if (unit.attackCooldown > 0) continue;
    const levelBoost = 1 + (unit.level - 1) * .1;
    const power = op.damage * levelBoost;
    if (op.damageType === 'heal') {
      const targets = units.filter((u) => u.hp < u.maxHp && isInAttackRange(unit, u.cell)).sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp).slice(0, unit.opId === 'echo' ? 2 : 1);
      if (targets.length) {
        targets.forEach((target) => healing.set(target.id, (healing.get(target.id) || 0) + power));
        unit.attackTargetRow = Math.floor(targets[0].cell / COLS);
        unit.attackTargetCol = targets[0].cell % COLS;
        unit.attackCooldown = op.attackInterval * (unit.level >= 6 ? .9 : 1);
        unit.attackFx = .82;
      }
      continue;
    }
    const targets = enemies.filter((e) => e.hp > 0 && enemyInUnitRange(unit, e, state.stageId)).sort((a, b) => unit.opId === 'kite' ? Number(b.markTimer > 0) - Number(a.markTimer > 0) || Number(b.kind === 'runner') - Number(a.kind === 'runner') || enemyProgress(b, state.stageId) - enemyProgress(a, state.stageId) : enemyProgress(b, state.stageId) - enemyProgress(a, state.stageId));
    const target = targets[0];
    if (target) {
      const targetPoint = pathCoordinates(target.pos, state.stageId, target.route);
      const raw = power;
      const blockedTargets = enemies.filter((enemy) => blockedBy.get(enemy.id)?.id === unit.id);
      const hitTargets = unit.opId === 'clockline' && unit.skillTimer > 0
        ? enemies.filter((enemy) => enemy.hp > 0 && enemyInUnitRange(unit, enemy, state.stageId))
        : unit.opId === 'clockline'
          ? enemies.filter((enemy) => {
            if (enemy.hp <= 0) return false;
            const point = pathCoordinates(enemy.pos, state.stageId, enemy.route);
            return Math.hypot(point.row - targetPoint.row, point.col - targetPoint.col) <= 1.15;
          })
          : unit.opId === 'loom' && unit.skillTimer > 0
            ? targets.slice(0, 3)
            : unit.opId === 'lith' && unit.skillTimer > 0 && blockedTargets.length
              ? blockedTargets
              : [target];
      let totalDealt = 0;
      hitTargets.forEach((enemy) => {
        const baseResistance = op.damageType === 'arcane' ? enemy.arcaneResistance : enemy.physicalResistance;
        const resistance = unit.opId === 'kite' && enemy.markTimer > 0 ? baseResistance * .25 : baseResistance;
        const shellGuard = enemy.kind === 'shell' && !blockedBy.has(enemy.id) && enemy.stunTimer <= 0;
        const guardMultiplier = shellGuard ? (state.stageId >= 14 && enemy.hp <= enemy.maxHp * .5 ? .75 : .88) : 1;
        const dealt = Math.max(raw * .1, raw * (1 - resistance)) * guardMultiplier;
        damageTaken.set(enemy.id, (damageTaken.get(enemy.id) || 0) + dealt);
        totalDealt += dealt;
      });
      if (unit.opId === 'lith' && unit.skillTimer > 0) healing.set(unit.id, (healing.get(unit.id) || 0) + totalDealt * .32);
      if (unit.opId === 'loom') hitTargets.forEach((enemy) => slowedEnemies.add(enemy.id));
      if (unit.opId === 'flare') costFromTraits += 1;
      unit.attackTargetRow = targetPoint.row;
      unit.attackTargetCol = targetPoint.col;
      unit.attackCooldown = op.attackInterval * (unit.level >= 6 ? .9 : 1);
      unit.attackFx = .78;
    }
  }
  enemies = enemies.map((e) => {
    const damage = damageTaken.get(e.id) || 0;
    return { ...e, hp: e.hp - damage, hitFx: damage > 0 ? .3 : e.hitFx, slowTimer: slowedEnemies.has(e.id) ? Math.max(e.slowTimer, 1.6) : e.slowTimer };
  });
  units = units.map((u) => {
    const restored = healing.get(u.id) || 0;
    return { ...u, hp: Math.min(u.maxHp, u.hp + restored), healFx: restored > 0 ? .55 : u.healFx };
  });

  const defeatedRust = enemies.filter((e) => e.hp <= 0 && e.kind === 'rust').length;
  const killedNow = enemies.filter((e) => e.hp <= 0).length;
  const leakedNow = enemies.filter((e) => e.pos >= stagePath(state.stageId, e.route).length - .1 && e.hp > 0).length;
  enemies = enemies.filter((e) => e.hp > 0 && e.pos < stagePath(state.stageId, e.route).length - .1);
  const killed = state.killed + killedNow;
  const lives = Math.max(0, state.lives - leakedNow);
  const mode: GameMode = lives <= 0 ? 'lost' : spawned >= stage.total && enemies.length === 0 ? 'won' : 'running';
  return {
    ...state, mode, elapsed, nextSpawn, spawned, enemies, units, redeploy, killed, lives,
    cost: Math.min(99, state.cost + dt * 1.05 + costFromTraits + defeatedRust),
    selectedUnit: units.some((u) => u.id === state.selectedUnit) ? state.selectedUnit : null,
    message: mode === 'won' ? '零号广播：回收完成。调度员，这段昨日属于你。' : mode === 'lost' ? '零号广播：时间线再次坍塌。我们还会回到这个早晨。' : message,
  };
}

type DragPlacement = {
  opId: OperatorId; x: number; y: number; targetCell: number | null;
  direction: Direction; cancelling: boolean; centerX: number | null; centerY: number | null;
  phase: 'dragging' | 'direction'; directionActive: boolean; directionArmed: boolean;
};

export default function Home() {
  const [game, dispatch] = useReducer(gameReducer, initialState);
  const [tutorial, setTutorial] = useState(true);
  const [drag, setDrag] = useState<DragPlacement | null>(null);
  const [rosterOp, setRosterOp] = useState<OperatorId | null>(null);
  const [progress, setProgress] = useState<PlayerProgress>({ fragments: 120, cleared: 0, levels: defaultLevels, squad: initialState.squad });
  const [formationSquad, setFormationSquad] = useState<OperatorId[]>(initialState.squad);
  const [lobbySection, setLobbySection] = useState<LobbySection>('home');
  const [progressLoaded, setProgressLoaded] = useState(false);
  const dragRef = useRef<DragPlacement | null>(null);
  const rewardedRunRef = useRef<number | null>(null);
  const gameRef = useRef(game);
  const attackSoundPoolRef = useRef<Map<string, HTMLAudioElement>>(new Map());
  const activeSoundsRef = useRef<Set<HTMLAudioElement>>(new Set());
  const soundTimersRef = useRef<Set<number>>(new Set());
  const previousAttackFxRef = useRef<Map<number, number>>(new Map());
  gameRef.current = game;

  useEffect(() => {
    const pool = new Map<string, HTMLAudioElement>();
    const sources = new Set(operatorIds.flatMap((opId) => operatorSoundSettings[opId].map((layer) => layer.src)));
    for (const src of sources) {
      const sound = new Audio(src);
      sound.preload = 'auto';
      pool.set(src, sound);
    }
    attackSoundPoolRef.current = pool;
    return () => {
      for (const timer of soundTimersRef.current) window.clearTimeout(timer);
      soundTimersRef.current.clear();
      for (const sound of activeSoundsRef.current) sound.pause();
      activeSoundsRef.current.clear();
      attackSoundPoolRef.current.clear();
    };
  }, []);

  useEffect(() => {
    const previous = previousAttackFxRef.current;
    const next = new Map<number, number>();
    for (const unit of game.units) {
      const priorFx = previous.get(unit.id) || 0;
      if (unit.attackFx > 0 && priorFx <= 0) {
        playOperatorAttackSound(attackSoundPoolRef.current, unit.opId, activeSoundsRef.current, soundTimersRef.current);
      }
      next.set(unit.id, unit.attackFx);
    }
    previousAttackFxRef.current = next;
  }, [game.units]);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem('yesterday-loop-progress-v1');
      if (saved) {
        const parsed = JSON.parse(saved) as Partial<PlayerProgress>;
        const levels = { ...defaultLevels };
        operatorIds.forEach((opId) => { levels[opId] = Math.max(1, Math.min(MAX_LEVEL, Number(parsed.levels?.[opId]) || 1)); });
        const savedSquad = Array.isArray(parsed.squad) ? [...new Set(parsed.squad.filter((id): id is OperatorId => operatorIds.includes(id as OperatorId)))].slice(0, 6) : initialState.squad;
        const squad = savedSquad.length ? savedSquad : initialState.squad;
        setFormationSquad(squad);
        setProgress({ fragments: Math.max(0, Number(parsed.fragments) || 0), cleared: Math.max(0, Math.min(stageIds.length, Number(parsed.cleared) || 0)), levels, squad });
      }
    } catch { /* 损坏的本地存档会自动使用默认进度。 */ }
    setProgressLoaded(true);
  }, []);

  useEffect(() => {
    if (progressLoaded) window.localStorage.setItem('yesterday-loop-progress-v1', JSON.stringify(progress));
  }, [progress, progressLoaded]);

  useEffect(() => {
    if (game.mode !== 'won' || rewardedRunRef.current === game.runId) return;
    rewardedRunRef.current = game.runId;
    const stage = stages[game.stageId];
    setProgress((current) => ({ ...current, fragments: current.fragments + stage.reward, cleared: Math.max(current.cleared, game.stageId) }));
  }, [game.mode, game.runId, game.stageId]);

  const enterStage = (stageId: StageId) => {
    if (stageId > progress.cleared + 1) return;
    setLobbySection('operations');
    setFormationSquad(progress.squad);
    dispatch({ type: 'PREPARE', stageId, levels: progress.levels, squad: progress.squad });
  };

  const toggleFormationOperator = (opId: OperatorId) => {
    setFormationSquad((current) => current.includes(opId) ? current.filter((id) => id !== opId) : current.length < 6 ? [...current, opId] : current);
  };

  const confirmFormation = () => {
    if (!formationSquad.length) return;
    const squad = [...formationSquad];
    setProgress((current) => ({ ...current, squad }));
    setTutorial(true);
    rewardedRunRef.current = null;
    dispatch({ type: 'BEGIN', stageId: game.stageId, levels: progress.levels, squad, runId: Date.now() });
  };

  const upgradeOperator = (opId: OperatorId) => {
    setProgress((current) => {
      const level = current.levels[opId];
      const cost = upgradeCost(level);
      if (level >= MAX_LEVEL || current.fragments < cost) return current;
      return { ...current, fragments: current.fragments - cost, levels: { ...current.levels, [opId]: level + 1 } };
    });
  };

  const returnToLobby = (section: LobbySection = 'operations') => {
    setLobbySection(section);
    setRosterOp(null);
    dispatch({ type: 'LOBBY' });
  };

  const beginPlacement = (opId: OperatorId, event: React.PointerEvent<HTMLButtonElement>) => {
    const current = gameRef.current;
    const op = operators[opId];
    if (current.cost < op.cost || current.redeploy[opId] > 0 || current.units.some((unit) => unit.opId === opId)) return;
    event.preventDefault();
    setRosterOp(null);
    const next: DragPlacement = { opId, x: event.clientX, y: event.clientY, targetCell: null, direction: 'right', cancelling: false, centerX: null, centerY: null, phase: 'dragging', directionActive: false, directionArmed: false };
    dragRef.current = next;
    setDrag(next);
  };

  const beginDirection = (event: React.PointerEvent<HTMLElement>) => {
    const current = dragRef.current;
    if (!current || current.phase !== 'direction') return;
    event.preventDefault();
    event.stopPropagation();
    const next = { ...current, x: event.clientX, y: event.clientY, directionActive: true, directionArmed: false };
    dragRef.current = next;
    setDrag(next);
  };

  useEffect(() => {
    const nearestValidCell = (x: number, y: number, opId: OperatorId) => {
      const state = gameRef.current;
      const op = operators[opId];
      let best: { cell: number; centerX: number; centerY: number; distance: number } | null = null;
      for (const element of Array.from(document.querySelectorAll<HTMLElement>('[data-cell]'))) {
        const cell = Number(element.dataset.cell);
        if (!Number.isInteger(cell) || op.ground !== new Set(stagePath(state.stageId)).has(cell) || state.units.some((unit) => unit.cell === cell)) continue;
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distance = Math.hypot(x - centerX, y - centerY);
        const snapRadius = Math.max(rect.width, rect.height) * .82;
        if (distance <= snapRadius && (!best || distance < best.distance)) best = { cell, centerX, centerY, distance };
      }
      return best;
    };
    const move = (event: PointerEvent) => {
      const current = dragRef.current;
      if (!current) return;
      event.preventDefault();
      const element = document.elementFromPoint(event.clientX, event.clientY) as HTMLElement | null;
      const cancelling = !!element?.closest('[data-placement-cancel]');
      if (current.phase === 'dragging') {
        const nearest = cancelling ? null : nearestValidCell(event.clientX, event.clientY, current.opId);
        const next = { ...current, x: event.clientX, y: event.clientY, targetCell: nearest?.cell ?? null, centerX: nearest?.centerX ?? null, centerY: nearest?.centerY ?? null, cancelling };
        dragRef.current = next;
        setDrag(next);
        return;
      }
      if (!current.directionActive || current.centerX === null || current.centerY === null) return;
      const dx = event.clientX - current.centerX;
      const dy = event.clientY - current.centerY;
      const directionArmed = Math.max(Math.abs(dx), Math.abs(dy)) > 22;
      const direction = directionArmed ? (Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up')) : current.direction;
      const next = { ...current, x: event.clientX, y: event.clientY, direction, directionArmed, cancelling };
      dragRef.current = next;
      setDrag(next);
    };
    const finish = (event: PointerEvent) => {
      const current = dragRef.current;
      if (!current) return;
      if (current.phase === 'dragging') {
        const element = document.elementFromPoint(event.clientX, event.clientY) as HTMLElement | null;
        const cancelling = !!element?.closest('[data-placement-cancel]');
        const nearest = cancelling ? null : nearestValidCell(event.clientX, event.clientY, current.opId);
        if (!nearest) {
          dragRef.current = null;
          setDrag(null);
          return;
        }
        const next: DragPlacement = { ...current, phase: 'direction', targetCell: nearest.cell, centerX: nearest.centerX, centerY: nearest.centerY, x: nearest.centerX, y: nearest.centerY, cancelling: false, directionActive: false, directionArmed: false };
        dragRef.current = next;
        setDrag(next);
        return;
      }
      if (current.cancelling) {
        dragRef.current = null;
        setDrag(null);
        return;
      }
      if (current.directionActive && current.directionArmed && current.targetCell !== null) {
        dispatch({ type: 'DEPLOY', cell: current.targetCell, opId: current.opId, direction: current.direction });
        dragRef.current = null;
        setDrag(null);
      } else {
        const next = { ...current, directionActive: false, directionArmed: false };
        dragRef.current = next;
        setDrag(next);
      }
    };
    const cancel = () => { dragRef.current = null; setDrag(null); };
    window.addEventListener('pointermove', move, { passive: false });
    window.addEventListener('pointerup', finish);
    window.addEventListener('pointercancel', cancel);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', finish);
      window.removeEventListener('pointercancel', cancel);
    };
  }, []);

  useEffect(() => {
    if (game.mode !== 'running') return;
    const timer = window.setInterval(() => dispatch({ type: 'TICK', dt: .1 * game.speed }), 100);
    return () => window.clearInterval(timer);
  }, [game.mode, game.speed]);

  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (event.code === 'Space' && (game.mode === 'running' || game.mode === 'paused')) { event.preventDefault(); dispatch({ type: 'PAUSE' }); }
      if (event.key === 'Escape' && dragRef.current) { dragRef.current = null; setDrag(null); return; }
      if (event.key === 'Escape') dispatch({ type: 'LOBBY' });
    };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [game.mode]);

  useEffect(() => {
    if (game.mode === 'title') setRosterOp(null);
  }, [game.mode]);

  if (game.mode === 'title') return <Title onStart={() => { setLobbySection('home'); dispatch({ type: 'LOBBY' }); }} />;
  if (game.mode === 'lobby') return <Lobby progress={progress} section={lobbySection} onSection={setLobbySection} onStage={enterStage} onUpgrade={upgradeOperator} onTitle={() => dispatch({ type: 'TITLE' })} />;
  if (game.mode === 'formation') return <Formation stageId={game.stageId} levels={progress.levels} squad={formationSquad} onToggle={toggleFormationOperator} onConfirm={confirmFormation} onBack={() => returnToLobby('operations')} />;
  const selectedUnit = game.units.find((u) => u.id === game.selectedUnit);
  const stage = stages[game.stageId];
  const routeProfile = stageRouteProfile(game.stageId);
  const currentRoutes = routeProfile.routes;
  const currentPathSet = new Set(currentRoutes.flat());
  const spawnCells = [...new Set(currentRoutes.map((route) => route[0]))];
  const goalCells = [...new Set(currentRoutes.map((route) => route[route.length - 1]))];
  const rangeSource: Pick<Unit, 'opId' | 'cell' | 'direction'> | undefined = drag && drag.targetCell !== null ? { opId: drag.opId, cell: drag.targetCell, direction: drag.direction } : selectedUnit;
  const wave = game.spawned < stage.cuts[0] ? 1 : game.spawned < stage.cuts[1] ? 2 : 3;

  return (
    <main className={`battle-shell chapter-theme-${stage.chapterId} ${game.units.some((unit) => unit.opId === 'anchor' && unit.skillFx > .45) ? 'screen-impact' : ''}`}>
      <header className="topbar">
        <button className="brand" onClick={() => returnToLobby('operations')}><b>昨日圆车</b><span>{stage.operation} · {stage.location}</span></button>
        <div className="battle-stats">
          <span className="life">守护点 ×{routeProfile.goals} <b>{'◆'.repeat(game.lives)}{'◇'.repeat(3 - game.lives)}</b></span>
          <span>击退 <b>{game.killed}</b><i> / {stage.total}</i></span>
          <span className="cost">C <b>{Math.floor(game.cost)}</b></span>
        </div>
        <div className="controls">
          <button onClick={() => dispatch({ type: 'PAUSE' })} aria-label={game.mode === 'paused' ? '继续' : '暂停'}>{game.mode === 'paused' ? '▶' : 'Ⅱ'}</button>
          <button onClick={() => dispatch({ type: 'SPEED' })} aria-label="切换倍速">×{game.speed}</button>
        </div>
      </header>

      <section className="battlefield" aria-label="战术地图" onClick={(event) => {
        const target = event.target as HTMLElement;
        if (target.closest('.unit-panel') || target.closest('.pause-layer') || target.closest('.placement-cancel')) return;
        if (!drag && !game.selected) { setRosterOp(null); dispatch({ type: 'CLEAR_UNIT' }); }
      }}>
        <div className="battle-environment" aria-hidden="true">
          <span className="env-pipe env-pipe-a" /><span className="env-pipe env-pipe-b" />
          <span className="env-signal"><i /><b>YR</b><small>07:42</small></span>
          <span className="env-fan"><i /><b /></span>
          <span className="env-barrier"><i /><i /><i /></span>
          <span className="env-service"><b>环城线检修区</b><small>MEMORY TRANSIT / KEEP CLEAR</small></span>
          <span className="env-steam env-steam-a" /><span className="env-steam env-steam-b" />
          <span className="env-scan" />
        </div>
        <div className="map-label"><span>{stage.location}</span><b>YESTERDAY / 07:42</b></div>
        <div className="grid-board">
          {Array.from({ length: 48 }, (_, cell) => {
            const unit = game.units.find((u) => u.cell === cell);
            const isPath = currentPathSet.has(cell);
            const placingOpId = drag?.phase === 'dragging' ? drag.opId : game.selected;
            const canDeploy = !!placingOpId && operators[placingOpId].ground === isPath && !unit;
            const inAttackRange = !!rangeSource && isInAttackRange(rangeSource, cell);
            const isDropTarget = drag?.targetCell === cell;
            const connectedCells = new Set<number>();
            currentRoutes.forEach((route) => {
              route.forEach((routeCell, index) => {
                if (routeCell !== cell) return;
                if (route[index - 1] !== undefined) connectedCells.add(route[index - 1]);
                if (route[index + 1] !== undefined) connectedCells.add(route[index + 1]);
              });
            });
            const railDirections = isPath ? [...connectedCells].map((neighbor): Direction | null => {
              if (neighbor === cell - COLS) return 'up';
              if (neighbor === cell + COLS) return 'down';
              if (neighbor === cell - 1) return 'left';
              if (neighbor === cell + 1) return 'right';
              return null;
            }).filter((direction): direction is Direction => direction !== null) : [];
            const isJunction = railDirections.length >= 3;
            return <button key={cell} data-cell={cell} data-unit={unit?.id} className={`${isPath ? 'path-cell' : 'high-cell'} ${isJunction ? 'junction-cell' : ''} ${canDeploy ? 'can-deploy' : ''} ${unit ? 'occupied' : ''} ${inAttackRange ? 'attack-range' : ''} ${isDropTarget ? 'drop-target' : ''}`} onClick={(event) => {
              if (unit) { event.stopPropagation(); setRosterOp(null); dispatch({ type: 'SELECT_UNIT', id: unit.id }); }
              else if (game.selected) dispatch({ type: 'DEPLOY', cell, direction: 'right' });
              else if (!drag) dispatch({ type: 'CLEAR_UNIT' });
            }} aria-label={unit ? `${operators[unit.opId].name}，点击查看攻击范围` : `部署格 ${cell + 1}${inAttackRange ? '，在攻击范围内' : ''}`}>
              {isPath && <i className="rail-mark">{railDirections.map((direction) => <b className={`rail-${direction}`} key={direction} />)}<em />{isJunction && <strong>岔</strong>}</i>}
              {!isPath && <i className="platform-mark"><b>H</b><span /></i>}
              {unit && <UnitFigure unit={unit} selected={game.selectedUnit === unit.id} />}
              {isDropTarget && drag?.phase === 'dragging' && <span className="drop-preview">落</span>}
              {isDropTarget && drag?.phase === 'direction' && <span className={`direction-selector direction-${drag.direction} ${drag.directionActive ? 'active' : ''} ${drag.directionArmed ? 'armed' : ''}`} onPointerDown={beginDirection} onClick={(event) => event.stopPropagation()}><OperatorModel opId={drag.opId} /><i className="dir-up">↑</i><i className="dir-right">→</i><i className="dir-down">↓</i><i className="dir-left">←</i><b>{drag.directionActive ? (drag.directionArmed ? `松手：朝${directionName(drag.direction)}部署` : '继续向一个方向滑动') : '按住角色，滑动定向'}</b></span>}
            </button>;
          })}
          {game.enemies.map((enemy) => <EnemyFigure key={enemy.id} enemy={enemy} stageId={game.stageId} />)}
          {spawnCells.map((cell, index) => <div className="spawn-gate" key={`spawn-${cell}`} style={{ '--gate-row': Math.floor(cell / COLS) } as React.CSSProperties}><b>入{spawnCells.length > 1 ? index + 1 : ''}</b><small>裂口</small></div>)}
          {goalCells.map((cell, index) => <div className="goal-gate" key={`goal-${cell}`} style={{ '--gate-row': Math.floor(cell / COLS) } as React.CSSProperties}><b>守{goalCells.length > 1 ? index + 1 : ''}</b><small>昨日</small></div>)}
        </div>

        <div className="mission-card"><span>{stage.operation} · {stage.location} / WAVE {String(wave).padStart(2, '0')}</span><b>{game.message}</b><p>{game.mode === 'briefing' ? stage.objective : `${routeProfile.spawns} 处裂口 · ${routeProfile.routes.length} 条路线 · ${routeProfile.goals} 个守护点；共享防线生命归零时行动失败。`}</p></div>
        <div className="legend"><span><i className="ground-dot" />地面轨道 · 近战</span><span><i className="high-dot" />架空高台 · 远程</span></div>

        {rosterOp ? <RosterPanel opId={rosterOp} level={game.levels[rosterOp]} onClose={() => setRosterOp(null)} /> : selectedUnit && <UnitPanel unit={selectedUnit} onSkill={() => dispatch({ type: 'SKILL' })} onRetreat={() => dispatch({ type: 'RETREAT' })} />}
        {game.mode === 'paused' && <div className="pause-layer"><b>行动暂停</b><span>时间线已冻结</span><div className="pause-actions"><button onClick={() => dispatch({ type: 'PAUSE' })}>继续行动</button><button onClick={() => { dragRef.current = null; setDrag(null); returnToLobby('operations'); }}>返回行动终端</button></div></div>}
        {(game.mode === 'won' || game.mode === 'lost') && <Result mode={game.mode} lives={game.lives} stageId={game.stageId} stage={stage} onAgain={() => { setTutorial(true); rewardedRunRef.current = null; dispatch({ type: 'RESTART' }); }} onTitle={() => returnToLobby('operations')} />}
        {tutorial && game.mode === 'briefing' && <Tutorial stageId={game.stageId} stage={stage} onClose={() => { setTutorial(false); dispatch({ type: 'START' }); }} />}
      </section>

      <aside className="squad-bar">
        <div className="deck-title"><b>行者</b><span>DEPLOY</span></div>
        {game.squad.map((opId) => {
          const op = operators[opId];
          const deployed = game.units.some((u) => u.opId === opId);
          const affordable = game.cost >= op.cost;
          const redeployLeft = game.redeploy[opId];
          const cooling = redeployLeft > 0;
          return <button key={opId} data-role={op.role.split(' / ')[0]} className={`operator-card ${game.selected === opId || drag?.opId === opId || rosterOp === opId ? 'selected' : ''} ${!affordable || deployed || cooling ? 'unavailable' : ''} ${cooling ? 'cooling' : ''}`} onPointerDown={(event) => beginPlacement(opId, event)} onClick={() => { setRosterOp(opId); dispatch({ type: 'CLEAR_UNIT' }); }} onKeyDown={(event) => { if (event.key === 'Enter') setRosterOp(opId); if (event.key === ' ' && !cooling) dispatch({ type: 'SELECT', opId }); }} disabled={deployed} aria-label={`点击查看${op.name}档案，拖动部署，费用 ${op.cost}${cooling ? `，再部署还需 ${Math.ceil(redeployLeft)} 秒` : ''}`}>
            <div className="avatar" style={{ '--op-color': op.color } as React.CSSProperties}><OperatorArt opId={opId} /></div>
            <span><b>{op.name} <i>Lv.{game.levels[opId]}</i></b><small>{deployed ? '行动中' : cooling ? `重整中 · ${Math.ceil(redeployLeft)}s` : op.role}</small></span><em>{op.cost}</em>{cooling && <i className="redeploy-timer"><b>{Math.ceil(redeployLeft)}</b><small>再部署</small></i>}
          </button>;
        })}
        {game.mode === 'briefing' ? <button className="start-wave" onClick={() => { setTutorial(false); dispatch({ type: 'START' }); }}><span>开始行动</span><small>OPERATION START　▶</small></button> : <div className="wave-meter"><span>WAVE {wave} / 3</span><i><b style={{ width: `${(game.spawned / stage.total) * 100}%` }} /></i></div>}
      </aside>
      {drag && <><div className="placement-step"><b>{drag.phase === 'dragging' ? '01' : '02'}</b><span>{drag.phase === 'dragging' ? '在目标位置松手，确认落点' : '按住角色向上下左右滑动，松手部署'}</span></div>{drag.phase === 'dragging' && <div className={`placement-ghost ${drag.targetCell !== null ? 'over-cell' : ''}`} style={{ left: drag.x, top: drag.y, '--op-color': operators[drag.opId].color } as React.CSSProperties}><OperatorModel opId={drag.opId} /><b>{operators[drag.opId].name}</b><span>{drag.targetCell !== null ? '松手确定落点' : '拖到可部署地块'}</span></div>}<button className={`placement-cancel ${drag.cancelling ? 'active' : ''}`} data-placement-cancel onClick={() => { dragRef.current = null; setDrag(null); }}><b>×</b><span>取消部署</span></button></>}
    </main>
  );
}

function Title({ onStart }: { onStart: () => void }) {
  return <main className="start-screen"><div className="signal-grid" aria-hidden="true" /><div className="roundel" aria-hidden="true"><span>昨</span></div><section className="start-copy"><p className="kicker">YESTERDAY LOOP / TACTICAL DEFENSE</p><h1>昨日圆车</h1><p className="subtitle">昨日值得被守护，但明日必须由放下昨日的人亲自抵达。</p><button className="primary-button" onClick={onStart}><span>进入调度大厅</span><small>ENTER ROUND TRAIN</small></button><div className="feature-line"><span>5 个章节</span><span>15 段行动</span><span>6 人编队</span><span>9 名行者</span></div></section><div className="title-lore"><b>“昨日失窃”后，城市每天午夜都会失去前一天的记忆。</b><p>被夺走的过去在未来凝成回收兽。你守护圆车里的残存记忆，而每取回一段昨日，就会遗忘自己更久以前的一段人生。</p><i>零号广播：请不要寻找我。找到我的那一天，就是圆车停下的那一天。</i></div><div className="start-foot"><span>CHAPTER 01—05 · 完整调度线</span><span>原创角色设定 · 昨日圆车</span></div></main>;
}

function Lobby({ progress, section, onSection, onStage, onUpgrade, onTitle }: { progress: PlayerProgress; section: LobbySection; onSection: (section: LobbySection) => void; onStage: (id: StageId) => void; onUpgrade: (id: OperatorId) => void; onTitle: () => void }) {
  const initialChapter = Math.min(chapters.length, Math.floor(progress.cleared / 3) + 1);
  const [selectedChapter, setSelectedChapter] = useState(initialChapter);
  const nextStageId = Math.min(stageIds.length, progress.cleared + 1) as StageId;
  const nextStage = stages[nextStageId];
  const totalLevels = operatorIds.reduce((sum, opId) => sum + progress.levels[opId], 0);
  const recoveredText = progress.cleared > 0 ? stages[progress.cleared as StageId].victory : '档案尚未恢复。第一份昨日仍在环城旧线等待调度。';
  const chapterStages = stageIds.filter((stageId) => stages[stageId].chapterId === selectedChapter);

  return <main className="lobby lobby-system">
    <header className="lobby-header"><button className="brand" onClick={onTitle}><b>昨日圆车</b><span>逆行调度大厅</span></button><div className="lobby-status"><span>主线进度 <b>{progress.cleared}/{stageIds.length}</b></span><div className="resource-chip"><small>培养资源</small><b>◆ {progress.fragments}</b><span>昨日残片</span></div></div></header>
    <div className="lobby-shell">
      <nav className="lobby-rail" aria-label="大厅系统">
        <button className={section === 'home' ? 'active' : ''} onClick={() => onSection('home')}><i>⌂</i><span>调度大厅</span><small>HALL</small></button>
        <button className={section === 'operations' ? 'active' : ''} onClick={() => onSection('operations')}><i>▶</i><span>战斗副本</span><small>OPERATIONS</small></button>
        <button className={section === 'training' ? 'active' : ''} onClick={() => onSection('training')}><i>◆</i><span>行者养成</span><small>TRAINING</small></button>
        <button className={section === 'archive' ? 'active' : ''} onClick={() => onSection('archive')}><i>▤</i><span>剧情档案</span><small>ARCHIVE</small></button>
        <button className={section === 'announcements' ? 'active' : ''} onClick={() => onSection('announcements')}><i>!</i><span>更新公告 <em>NEW</em></span><small>NOTICE</small></button>
      </nav>

      <section className="lobby-content">
        {section === 'home' && <div className="hall-view">
          <section className="hall-hero"><p>LAST DISPATCHER / 07:42</p><h1>{progress.cleared >= stageIds.length ? '圆车已经停下，时间重新开始。' : '调度员，今天要追回哪一段昨日？'}</h1><span>{progress.cleared >= stageIds.length ? '全部主线档案已恢复。你仍可重返行动、培养行者并查阅完整剧情。' : `下一行动 ${nextStage.operation} · ${nextStage.title}，地点：${nextStage.location}。`}</span><button onClick={() => { onSection('operations'); setSelectedChapter(nextStage.chapterId); }}>{progress.cleared >= stageIds.length ? '重返行动终端' : '前往下一副本'}<small>OPEN OPERATION</small></button></section>
          <div className="hall-metrics"><article><small>主线恢复率</small><b>{Math.round(progress.cleared / stageIds.length * 100)}%</b><i><span style={{ width: `${progress.cleared / stageIds.length * 100}%` }} /></i></article><article><small>行者同调等级</small><b>{totalLevels}</b><span>9 名行者 · 上限 {MAX_LEVEL * operatorIds.length}</span></article><article><small>昨日残片</small><b>◆ {progress.fragments}</b><span>用于永久提升生命、攻击与治疗</span></article></div>
          <div className="hall-modules"><button onClick={() => onSection('operations')}><small>01 / COMBAT</small><b>战斗副本</b><span>5 个章节、15 段连续行动，逐关解锁。</span><i>进入行动终端 →</i></button><button onClick={() => onSection('training')}><small>02 / GROWTH</small><b>行者养成</b><span>消耗通关残片，提升到 Lv.{MAX_LEVEL} 并解锁攻速同调。</span><i>进入训练舱 →</i></button><button onClick={() => onSection('archive')}><small>03 / STORY</small><b>剧情档案</b><span>重读已夺回的昨日，追踪零号、迟鸦与小满的真相。</span><i>打开回收档案 →</i></button><button className="notice-module" onClick={() => onSection('announcements')}><small>04 / NOTICE · NEW</small><b>更新公告</b><span>查看每次版本新增、调整与修复内容。</span><i>阅读最新公告 →</i></button></div>
          <section className="zero-console"><div><small>ZERO / BROADCAST LOG</small><b>零号广播</b></div><p>{progress.cleared >= 9 ? '你已经找到我。接下来不要服从广播，请亲自决定圆车的方向。' : progress.cleared >= 3 ? '循环已经被证实。不要害怕记住失败，害怕的是把失败当成唯一结局。' : '请不要寻找我。找到我的那一天，就是圆车停下的那一天。'}</p></section>
          <section className="latest-memory"><header><span>最近恢复的剧情</span><button onClick={() => onSection('archive')}>查看全部</button></header><p>{recoveredText}</p></section>
        </div>}

        {section === 'operations' && <div className="operations-view"><header className="section-heading"><div><small>ROUND TRAIN / OPERATION TERMINAL</small><h1>战斗副本</h1><p>每章三关。通关当前行动后解锁下一段时间线，重复行动仍可获得培养资源。</p></div><b>{progress.cleared} / {stageIds.length}</b></header>
          <div className="chapter-tabs">{chapters.map((chapter) => { const firstStage = (chapter.id - 1) * 3 + 1; const locked = firstStage > progress.cleared + 1; const complete = progress.cleared >= firstStage + 2; return <button key={chapter.id} className={`${selectedChapter === chapter.id ? 'active' : ''} ${locked ? 'locked' : ''}`} onClick={() => setSelectedChapter(chapter.id)} style={{ '--chapter-color': chapter.color } as React.CSSProperties}><small>{chapter.no}</small><b>{chapter.title}</b><span>{complete ? '章节完成' : locked ? '时间线锁定' : '行动可用'}</span></button>; })}</div>
          <section className="chapter-banner" style={{ '--chapter-color': chapters[selectedChapter - 1].color } as React.CSSProperties}><small>{chapters[selectedChapter - 1].no}</small><h2>{chapters[selectedChapter - 1].title}</h2><p>{chapters[selectedChapter - 1].subtitle}</p></section>
          <div className="operation-grid">{chapterStages.map((stageId) => { const stage = stages[stageId]; const locked = stageId > progress.cleared + 1; const cleared = progress.cleared >= stageId; return <button key={stageId} className={`operation-card ${locked ? 'locked' : ''} ${cleared ? 'cleared' : ''}`} disabled={locked} onClick={() => onStage(stageId)}><div className="operation-no"><small>{stage.chapter}</small><b>{stage.operation}</b></div><section><small>{stage.location}</small><h3>{stage.title}</h3><p>{stage.objective}</p><div>{stage.intel.map((kind) => <span key={kind}>{monsters[kind].code}</span>)}</div></section><aside><b>{locked ? '锁定' : cleared ? '再次行动' : '开始行动'}</b><small>◆ {stage.reward}</small></aside></button>; })}</div>
        </div>}

        {section === 'training' && <div className="training-view"><header className="section-heading"><div><small>MEMORY SYNCHRONIZATION / TRAINING BAY</small><h1>行者养成</h1><p>升级永久保存。每级生命 +12%、攻击或治疗 +10%；Lv.6 起攻击间隔额外缩短 10%。</p></div><b>◆ {progress.fragments}</b></header><div className="training-summary"><article><small>同调总等级</small><b>{totalLevels} / {MAX_LEVEL * operatorIds.length}</b></article><article><small>下一阶段</small><b>{operatorIds.some((id) => progress.levels[id] < 6) ? 'Lv.6 攻速同调' : '全员深层同调'}</b></article><article><small>资源来源</small><b>战斗副本结算</b></article></div><section className="upgrade-roster"><div>{operatorIds.map((opId) => { const op = operators[opId]; const level = progress.levels[opId]; const maxed = level >= MAX_LEVEL; const cost = upgradeCost(level); return <article className="upgrade-card" key={opId} style={{ '--op-color': op.color } as React.CSSProperties}><div className="upgrade-portrait"><OperatorArt opId={opId} /></div><section><small>{op.role.split(' / ')[0]} · {trainingPhase(level)}</small><b>{op.name} <i>Lv.{level}</i></b><div className="level-pips">{Array.from({ length: MAX_LEVEL }, (_, i) => <i key={i} className={i < level ? 'on' : ''} />)}</div><span>HP {levelHp(opId, level)}　{op.damageType === 'heal' ? 'HEAL' : 'ATK'} {levelAttack(opId, level)}</span><em>{level >= 6 ? '攻速同调已激活 · 间隔 -10%' : `升至 Lv.6 解锁攻速同调`}</em></section><button className="upgrade-button" disabled={maxed || progress.fragments < cost} onClick={() => onUpgrade(opId)}>{maxed ? <><b>已满级</b><small>MAX</small></> : <><b>升级</b><small>◆ {cost}</small></>}</button></article>; })}</div></section></div>}

        {section === 'archive' && <div className="archive-view"><header className="section-heading"><div><small>RECOVERED MEMORY / STORY ARCHIVE</small><h1>剧情档案</h1><p>行动结束后，调度员夺回一段昨日，也会永久失去自己更早的一段人生。章节幕间和行动余波会随进度解锁。</p></div><b>{progress.cleared} 份</b></header><div className="archive-chapters">{chapters.map((chapter) => { const ids = stageIds.filter((id) => stages[id].chapterId === chapter.id); const recovered = ids.filter((id) => id <= progress.cleared); const interlude = chapterInterludes.find((entry) => entry.chapterId === chapter.id)!; const interludeUnlocked = progress.cleared >= interlude.unlock; return <section key={chapter.id} style={{ '--chapter-color': chapter.color } as React.CSSProperties}><header><div><small>{chapter.no}</small><h2>{chapter.title}</h2></div><b>{recovered.length} / 3</b></header><p>{chapter.subtitle}</p><div><details className={`chapter-interlude ${interludeUnlocked ? '' : 'locked'}`}><summary><span>幕间</span><b>{interludeUnlocked ? interlude.title : '尚未恢复'}</b><i>{interludeUnlocked ? interlude.code : 'LOCKED'}</i></summary>{interludeUnlocked && <div>{interlude.body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}<ul>{interlude.dialogue.map((line, index) => <li key={index}><b>{line.speaker}</b><span>{line.text}</span></li>)}</ul></div>}</details>{ids.map((stageId) => { const stage = stages[stageId]; const extra = stageStoryExtras[stageId]; const unlocked = stageId <= progress.cleared; return <details key={stageId} className={unlocked ? '' : 'locked'}><summary><span>{stage.operation}</span><b>{unlocked ? stage.title : '尚未恢复'}</b><i>{unlocked ? '展开记录' : 'LOCKED'}</i></summary>{unlocked && <div><p>{stage.story}</p><p className="archive-extra">{extra.briefing}</p><blockquote>{stage.quote}</blockquote><ul>{[...stage.dialogue, ...extra.dialogue].map((line, index) => <li key={index}><b>{line.speaker}</b><span>{line.text}</span></li>)}</ul><em>行动结算：{stage.victory}</em><section className="archive-aftermath"><b>行动余波</b><p>{extra.aftermath}</p>{extra.aftermathDialogue.map((line, index) => <div key={index}><strong>{line.speaker}</strong><span>{line.text}</span></div>)}</section></div>}</details>; })}</div></section>; })}</div></div>}

        {section === 'announcements' && <div className="announcements-view"><header className="section-heading"><div><small>ROUND TRAIN / UPDATE NOTICE</small><h1>更新公告</h1><p>圆车的每一次调整都会在这里留下记录。新版本发布时，本栏目将同步追加更新内容。</p></div><b>{announcements.length} 期</b></header><section className="notice-featured"><div><small>LATEST DISPATCH · {announcements[0].date}</small><span>{announcements[0].tag}</span></div><h2>{announcements[0].title}</h2><p>{announcements[0].summary}</p></section><div className="notice-list">{announcements.map((notice, index) => <article className={index === 0 ? 'latest' : ''} key={`${notice.date}-${notice.version}`}><header><div><small>{notice.version}</small><h2>{notice.title}</h2></div><span>{notice.date}</span></header><p>{notice.summary}</p><ul>{notice.changes.map((change) => <li key={change}>{change}</li>)}</ul>{index === 0 && <em>当前版本</em>}</article>)}</div></div>}
      </section>
    </div>
  </main>;
}

function Formation({ stageId, levels, squad, onToggle, onConfirm, onBack }: { stageId: StageId; levels: OperatorLevels; squad: OperatorId[]; onToggle: (opId: OperatorId) => void; onConfirm: () => void; onBack: () => void }) {
  const stage = stages[stageId];
  const routeProfile = stageRouteProfile(stageId);
  const full = squad.length >= 6;
  const needsArcane = stage.intel.some((kind) => monsters[kind].physicalResistance >= .5);
  const needsPhysical = stage.intel.some((kind) => monsters[kind].arcaneResistance >= .5);
  return <main className="formation-screen">
    <header className="formation-header"><button onClick={onBack}>← 返回行动终端</button><div><small>{stage.chapter} / {stage.operation}</small><b>行动编队</b></div><span>编队上限 <b>{squad.length} / 6</b></span></header>
    <div className="formation-layout">
      <section className="formation-main"><header><small>SQUAD ASSEMBLY</small><h1>选择本次行动的六名行者。</h1><p>未编入队伍的行者不会出现在战斗预备栏。编队会保存为下次行动的默认选择。</p></header>
        <div className="squad-slots">{Array.from({ length: 6 }, (_, index) => { const opId = squad[index]; const op = opId ? operators[opId] : null; return <div key={index} className={op ? 'filled' : ''} style={op ? { '--op-color': op.color } as React.CSSProperties : undefined}>{op ? <><OperatorArt opId={opId} /><span><small>0{index + 1}</small><b>{op.name}</b><i>{op.role.split(' / ')[0]}</i></span><button onClick={() => onToggle(opId)} aria-label={`移除${op.name}`}>×</button></> : <b>空位 {index + 1}</b>}</div>; })}</div>
        <div className="formation-roster">{operatorIds.map((opId) => { const op = operators[opId]; const selected = squad.includes(opId); const damageLabel = op.damageType === 'physical' ? '物理' : op.damageType === 'arcane' ? '法术' : '治疗'; return <button key={opId} className={`${selected ? 'selected' : ''} ${full && !selected ? 'unavailable' : ''}`} onClick={() => onToggle(opId)} disabled={full && !selected} style={{ '--op-color': op.color } as React.CSSProperties}><div><OperatorArt opId={opId} /></div><span><small>{op.identity}</small><b>{op.name} <i>Lv.{levels[opId]}</i></b><em>{op.role} · {damageLabel}</em><p>{op.trait}</p><q>{op.skill} · {op.skillDesc}</q></span><strong>{selected ? squad.indexOf(opId) + 1 : '+'}</strong></button>; })}</div>
      </section>
      <aside className="formation-intel"><small>ENEMY RESISTANCE</small><h2>{stage.title}</h2><p>{stage.objective}</p><div>{stage.intel.map((kind) => { const monster = monsters[kind]; return <article key={kind}><img src={monster.art} alt={monster.name} /><section><b>{monster.name}</b><span>物抗 <i className={monster.physicalResistance >= .5 ? 'high' : ''}>{Math.round(monster.physicalResistance * 100)}%</i></span><span>法抗 <i className={monster.arcaneResistance >= .5 ? 'high' : ''}>{Math.round(monster.arcaneResistance * 100)}%</i></span><small>{monster.trait}</small></section></article>; })}</div><div className="route-intel"><span><b>{routeProfile.spawns}</b><small>敌人入口</small></span><span><b>{routeProfile.routes.length}</b><small>行动路线</small></span><span><b>{routeProfile.goals}</b><small>守护点</small></span></div><div className="formation-advice"><b>调度建议</b><span>{needsArcane && needsPhysical ? '本关同时存在高物抗与高法抗目标，建议混编物理与法术输出。' : needsArcane ? '存在高物抗目标，建议编入迟鸦或钟离线。' : needsPhysical ? '存在高法抗目标，建议编入雾筝等物理行者。' : '敌方抗性较低，可根据阻挡与治疗需求自由搭配。'}{routeProfile.routes.length > 1 ? ` 敌人会从 ${routeProfile.spawns} 处裂口沿不同路线进攻，请保留机动位支援分岔。` : ''}</span></div><button className="formation-confirm" onClick={onConfirm} disabled={!squad.length}><b>确认编队</b><small>{squad.length}/6 · 前往行动简报</small></button></aside>
    </div>
  </main>;
}

function UnitFigure({ unit, selected }: { unit: Unit; selected: boolean }) {
  const op = operators[unit.opId];
  const unitRow = Math.floor(unit.cell / COLS);
  const unitCol = unit.cell % COLS;
  const tracksTarget = !op.ground && unit.attackTargetRow !== null && unit.attackTargetCol !== null;
  const targetRowDelta = tracksTarget ? unit.attackTargetRow! - unitRow : 0;
  const targetColDelta = tracksTarget ? unit.attackTargetCol! - unitCol : 0;
  const targetAngle = Math.atan2(targetRowDelta, targetColDelta) * 180 / Math.PI;
  const targetDistance = Math.max(.2, Math.hypot(targetRowDelta, targetColDelta));
  const projectileStyle = tracksTarget ? {
    '--fx-target-x': `${targetColDelta * 100}%`,
    '--fx-target-y': `${targetRowDelta * 100}%`,
    '--fx-angle': `${targetAngle}deg`,
    '--fx-cells': targetDistance,
  } as React.CSSProperties : undefined;
  const attackLabel: Record<OperatorId, string> = { lith: '盾击', kite: '光矢', bell: '逆算', mend: '缝合', flare: '拾忆', anchor: '轨锤', loom: '信号', echo: '声波', clockline: '钟爆' };
  return <div className={`unit-figure unit-${unit.opId} facing-${unit.direction} ${selected ? 'unit-selected' : ''} ${unit.attackFx > 0 ? 'unit-attacking' : ''} ${unit.skillFx > 0 ? 'unit-skill-cast' : ''} ${unit.hurtFx > 0 ? 'unit-hurt' : ''} ${unit.skillTimer > 0 ? 'unit-skill-active' : ''} ${unit.shield > 0 ? 'unit-shielded' : ''} ${unit.skill >= 100 && unit.skillTimer <= 0 ? 'unit-skill-ready' : ''}`} style={{ '--op-color': op.color } as React.CSSProperties}>
    <span className="operator-body"><OperatorModel opId={unit.opId} /></span>
    <strong className={`unit-direction direction-${unit.direction}`}>➤</strong>
    <i><b style={{ width: `${Math.max(0, unit.hp / unit.maxHp) * 100}%` }} /></i>
    {unit.shield > 0 && <span className="unit-shield" aria-label={`护盾 ${Math.ceil(unit.shield)}`}><b style={{ width: `${Math.min(100, unit.shield / unit.maxHp * 100)}%` }} /><em>{Math.ceil(unit.shield)}</em></span>}
    {unit.skill >= 100 && unit.skillTimer <= 0 && <span className="skill-ready-beacon" aria-label={`${op.skill}已就绪`}><i>◆</i><b>技能就绪</b></span>}
    {unit.skillTimer > 0 && <><em>SKILL</em><span className={`skill-aura aura-${unit.opId}`} aria-hidden="true" /></>}
    {unit.attackFx > 0 && <><span className={`weapon-motion weapon-${unit.opId}`} aria-hidden="true"><i /><b /></span><span className={`combat-fx fx-${unit.opId} ${tracksTarget ? 'fx-targeted' : ''}`} style={projectileStyle} aria-hidden="true"><i /><b /><em /><strong>{attackLabel[unit.opId]}</strong></span></>}
    {unit.skillFx > 0 && <span className={`skill-fx skill-${unit.opId}`} aria-hidden="true"><i /><b /><em /><strong>{op.skill}</strong></span>}
    {unit.healFx > 0 && <span className="heal-feedback" aria-hidden="true"><i /><b /><em /></span>}
  </div>;
}

function OperatorArt({ opId }: { opId: OperatorId }) {
  const op = operators[opId];
  if (op.sprite !== undefined) return <span className="pixel-art" aria-hidden="true" style={{ backgroundPosition: `${-op.sprite * 24}px 0` }} />;
  return <img src={op.art} alt="" aria-hidden="true" />;
}

function OperatorModel({ opId }: { opId: OperatorId }) {
  if (opId === 'clockline') return <span className="operator-cutout cutout-clockline" aria-hidden="true"><img src={operators[opId].art} alt="" /></span>;
  return <span className={`sprite-actor sprite-${opId}`} aria-hidden="true" />;
}

function MonsterModel({ kind }: { kind: EnemyKind }) {
  return <span className={`monster-sprite monster-sprite-${kind}`} aria-hidden="true"><img src={monsters[kind].art} alt="" /></span>;
}

function EnemyFigure({ enemy, stageId }: { enemy: Enemy; stageId: StageId }) {
  const { row, col } = pathCoordinates(enemy.pos, stageId, enemy.route);
  const monster = monsters[enemy.kind];
  const runnerSprint = stageId >= 2 && enemy.kind === 'runner' && enemy.pos < 2.2 && !enemy.attacking;
  const shellGuard = enemy.kind === 'shell' && !enemy.attacking && enemy.stunTimer <= 0;
  const clockFrenzy = stageId >= 15 && enemy.kind === 'clock' && enemy.hp <= enemy.maxHp * .5 && enemy.stunTimer <= 0;
  const mechanic = runnerSprint ? '冲刺' : shellGuard ? '护壳' : clockFrenzy ? '加速' : enemy.kind === 'wisp' && enemy.attacking ? '空袭' : enemy.kind === 'leech' && enemy.attacking ? '汲取' : null;
  return <div className={`enemy enemy-${enemy.kind} ${enemy.attacking ? 'enemy-attacking' : ''} ${enemy.attackFx > 0 ? 'enemy-striking' : ''} ${enemy.slowTimer > 0 ? 'enemy-slowed' : ''} ${enemy.stunTimer > 0 ? 'enemy-stunned' : ''} ${enemy.markTimer > 0 ? 'enemy-marked' : ''} ${enemy.hitFx > 0 ? 'enemy-hit' : ''} ${mechanic ? 'enemy-mechanic-active' : ''}`} style={{ '--row': row, '--col': col } as React.CSSProperties} title={`${monster.name}：${monster.trait} 物抗 ${Math.round(monster.physicalResistance * 100)}% / 法抗 ${Math.round(monster.arcaneResistance * 100)}%`}><i><b style={{ width: `${Math.max(0, enemy.hp / enemy.maxHp) * 100}%` }} /></i><MonsterModel kind={enemy.kind} />{enemy.attackFx > 0 && <span className={`monster-attack-fx monster-attack-${enemy.kind}`} aria-hidden="true"><b /><i /><em /></span>}<small>{monster.code}</small>{enemy.markTimer > 0 && <strong className="enemy-mark">定标</strong>}{enemy.stunTimer > 0 ? <em>停摆</em> : mechanic ? <em>{mechanic}</em> : enemy.attacking && <em>攻击</em>}</div>;
}

function UnitPanel({ unit, onSkill, onRetreat }: { unit: Unit; onSkill: () => void; onRetreat: () => void }) {
  const op = operators[unit.opId];
  return <aside className="unit-panel" onClick={(event) => event.stopPropagation()}><header><div style={{ background: op.color }}><OperatorArt opId={unit.opId} /></div><span><b>{op.name} · Lv.{unit.level}</b><small>{op.identity} · 朝{directionName(unit.direction)}</small></span><button onClick={onRetreat}>撤退</button></header><p className="unit-bio">{op.bio}</p><p className="unit-trait">{op.trait}</p><div className="unit-numbers"><span>HP <b>{Math.max(0, Math.ceil(unit.hp))}</b></span><span>护盾 <b>{Math.ceil(unit.shield)}</b></span><span>{op.damageType === 'heal' ? 'HEAL' : 'ATK'} <b>{levelAttack(unit.opId, unit.level)}</b></span><span>间隔 <b>{op.attackInterval.toFixed(2)}s</b></span></div><button className={`skill-button ${unit.skill >= 100 ? 'ready' : ''}`} onClick={onSkill} disabled={unit.skill < 100}><i style={{ '--charge': `${unit.skill * 3.6}deg` } as React.CSSProperties}>{unit.skill >= 100 ? '启' : Math.floor(unit.skill)}</i><span><b>{op.skill}</b><small>{op.skillDesc}</small></span></button></aside>;
}

function RosterPanel({ opId, level, onClose }: { opId: OperatorId; level: number; onClose: () => void }) {
  const op = operators[opId];
  return <aside className="unit-panel roster-panel" onClick={(event) => event.stopPropagation()}><header><div style={{ background: op.color }}><OperatorArt opId={opId} /></div><span><b>{op.name} · Lv.{level}</b><small>预备行者 · {op.identity}</small></span><button onClick={onClose}>关闭</button></header><p className="unit-bio">{op.bio}</p><p className="unit-trait">{op.trait}</p><div className="unit-numbers"><span>HP <b>{levelHp(opId, level)}</b></span><span>{op.damageType === 'heal' ? 'HEAL' : 'ATK'} <b>{levelAttack(opId, level)}</b></span><span>间隔 <b>{op.attackInterval.toFixed(2)}s</b></span><span>RNG <b>{op.range}</b></span></div><div className="roster-skill"><b>{op.skill}</b><small>{op.skillDesc}</small></div></aside>;
}

const storySpeakerOperators: Partial<Record<string, OperatorId>> = {
  岑昼: 'lith', 雾筝: 'kite', 迟鸦: 'bell', 祈修: 'mend', 小满: 'flare', 砾灯: 'anchor', 萤返: 'loom', 回声: 'echo', 钟离线: 'clockline',
};

function Tutorial({ stageId, stage, onClose }: { stageId: StageId; stage: typeof stages[StageId]; onClose: () => void }) {
  const extra = stageStoryExtras[stageId];
  const routeProfile = stageRouteProfile(stageId);
  const lines = [
    { speaker: '行动记录', text: stage.story, kind: 'narration' as const },
    { speaker: '现场记录', text: extra.briefing, kind: 'narration' as const },
    ...stage.dialogue.map((line) => ({ ...line, kind: 'dialogue' as const })),
    ...extra.dialogue.map((line) => ({ ...line, kind: 'dialogue' as const })),
    { speaker: '零号', text: stage.broadcast, kind: 'broadcast' as const },
  ];
  const [lineIndex, setLineIndex] = useState(0);
  const dialogueComplete = lineIndex >= lines.length;
  const current = lines[Math.min(lineIndex, lines.length - 1)];
  const portraitOpId = current ? storySpeakerOperators[current.speaker] : undefined;
  const isZero = current?.speaker.startsWith('零号');
  const isNarration = current?.kind === 'narration';
  const portraitSide = lineIndex % 2 === 0 ? 'left' : 'right';
  const chapterColor = chapters[stage.chapterId - 1].color;

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (dialogueComplete || !['Enter', ' ', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      setLineIndex((value) => Math.min(lines.length, value + 1));
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [dialogueComplete, lines.length]);

  const nextLine = () => setLineIndex((value) => Math.min(lines.length, value + 1));
  const previousLine = () => setLineIndex((value) => Math.max(0, value - 1));

  return <div className="story-briefing" style={{ '--story-color': chapterColor } as React.CSSProperties}>
    <div className="story-grid" />
    {!dialogueComplete ? <section className={`story-scene story-${current.kind}`} onClick={nextLine}>
      <header className="story-topline"><div><small>{stage.chapter}</small><b>{stage.operation} · {stage.title}</b></div><span>{String(lineIndex + 1).padStart(2, '0')} / {String(lines.length).padStart(2, '0')}</span></header>
      <div className="story-location"><small>MEMORY BEFORE OPERATION</small><b>{isNarration ? current.speaker : '圆车行动前记录'}</b><span>{stage.quote}</span></div>
      {portraitOpId && <div className={`story-portrait ${portraitSide}`}><div><OperatorArt opId={portraitOpId} /></div><span><small>{operators[portraitOpId].identity}</small><b>{operators[portraitOpId].name}</b></span></div>}
      {isZero && <div className={`story-zero ${portraitSide}`}><div><i>0</i><span>{Array.from({ length: 13 }, (_, index) => <b key={index} />)}</span></div><small>ROUND TRAIN BROADCAST</small><b>{current.speaker}</b></div>}
      {isNarration && <div className="story-memory-mark"><i>{stage.operation.replace('YR-', '')}</i><span>昨日残存记录<br />正在读取</span></div>}
      <button className="story-skip" onClick={(event) => { event.stopPropagation(); setLineIndex(lines.length); }}>跳过对话 <span>SKIP</span></button>
      <article className={`story-dialogue-box ${isNarration ? 'narrator' : ''}`}>
        <header><small>{current.kind === 'broadcast' ? 'ZERO / LIVE BROADCAST' : current.kind === 'narration' ? 'RECOVERED MEMORY' : 'WALKER / DIALOGUE'}</small><b>{current.speaker}</b></header>
        <p>{current.text}</p>
        <footer>
          <button disabled={lineIndex === 0} onClick={(event) => { event.stopPropagation(); previousLine(); }}>上一句</button>
          <span>点击画面或按 Enter 继续</span>
          <button onClick={(event) => { event.stopPropagation(); nextLine(); }}>{lineIndex === lines.length - 1 ? '进入敌情确认' : '下一句'}</button>
        </footer>
      </article>
    </section> : <section className="story-confirm">
      <header><div><small>{stage.chapter} / {stage.operation}</small><h2>{stage.title}。</h2><p>{stage.quote}</p></div><span><i>对话结束</i><b>敌情确认</b></span></header>
      <div className="story-confirm-layout">
        <section><small>ENEMY INTELLIGENCE</small><h3>本次行动目标</h3><p>{stage.story}</p><div className="enemy-intel">{stage.intel.map((kind) => <article key={kind}><img src={monsters[kind].art} alt={monsters[kind].name} /><span><b>{monsters[kind].name}</b><small>{monsters[kind].trait}</small><i>物抗 {Math.round(monsters[kind].physicalResistance * 100)}% · 法抗 {Math.round(monsters[kind].arcaneResistance * 100)}%</i></span></article>)}</div></section>
        <aside><small>TACTICAL NOTES</small><div className="route-intel"><span><b>{routeProfile.spawns}</b><small>敌人入口</small></span><span><b>{routeProfile.routes.length}</b><small>行动路线</small></span><span><b>{routeProfile.goals}</b><small>守护点</small></span></div><ol><li><b>观察抗性</b><span>高物抗使用术师，高法抗使用物理输出。</span></li><li><b>关注分岔</b><span>{routeProfile.routes.length > 1 ? '敌人沿多条路线交替出现，黄色“岔”标记适合布置机动防线。' : '本关为单路线，先熟悉阻挡、治疗与攻击方向。'}</span></li><li><b>机制技能</b><span>技力满后点击场上行者，按局势使用回溯、标记、护盾或控制。</span></li></ol><div className="brief-voice"><b>零号广播</b><span>调度确认后，战斗计时与敌人行动将同时开始。</span></div></aside>
      </div>
      <footer><button onClick={() => setLineIndex(lines.length - 1)}>回到对话</button><button className="story-start" onClick={onClose}><b>接受调度并开始行动</b><small>敌人将在确认后出现</small></button></footer>
    </section>}
  </div>;
}

function Result({ mode, lives, stageId, stage, onAgain, onTitle }: { mode: 'won' | 'lost'; lives: number; stageId: StageId; stage: typeof stages[StageId]; onAgain: () => void; onTitle: () => void }) {
  const won = mode === 'won';
  const extra = stageStoryExtras[stageId];
  return <div className={`result ${won ? 'victory' : 'defeat'}`}><p>{won ? 'MEMORY RECOVERED' : 'TIMELINE COLLAPSED'}</p><h2>{won ? `${stage.title}，回收完成。` : '昨日已经脱轨。'}</h2><div className="rank">{won ? 'S' : 'C'}</div><span>{won ? `剩余终点生命 ${lives} / 3 · 获得 ◆ ${stage.reward} 昨日残片` : '零号广播：你又失败了一次。我们会回到这个早晨。'}</span>{won && <div className="result-reveal"><b>回收档案 / {stage.operation}</b><span>{stage.victory}</span><section><strong>行动余波</strong><p>{extra.aftermath}</p><div className="result-dialogue">{extra.aftermathDialogue.map((line) => <div key={line.speaker}><b>{line.speaker}</b><span>{line.text}</span></div>)}</div></section><i>昨日值得被守护，但明日必须由放下昨日的人亲自抵达。</i></div>}<div className="result-actions"><button onClick={onAgain}>重新行动</button><button onClick={onTitle}>返回行动终端</button></div></div>;
}
